const express = require('express');
const { WebSocketServer } = require('ws');
const { userOf, chatOf, giftOf, likeOf } = require('./tiktok-adapter.js');
const { GameEngine, WORLD: WORLD_CFG } = require('./game.js');
const { avatarMiddleware, registerAvatar } = require('./avatar-proxy.js');
const http = require('http');
const path = require('path');
const crypto = require('crypto');

// ── Config ──────────────────────────────────────────────
const TIKTOK_USERNAME = (process.env.TIKTOK_USER || '@sliuenc').replace(/^@/, '');
const SIGN_API_KEY = process.env.EULER_KEY || ''; // API key gratis de https://www.eulerstream.com (necesaria para firmar la conexión)
const PORT = process.env.PORT || 3000;
const BUILD = Date.now(); // cambia en cada reinicio: las pantallas abiertas se recargan solas

// ── App setup ───────────────────────────────────────────
const app = express();
app.use(express.static(path.join(__dirname, 'public'), { etag: false, lastModified: false, setHeaders: r => r.setHeader('Cache-Control', 'no-store') }));
app.get('/avatar/:userId', avatarMiddleware);

// Lista de canciones en public/music (pon ahí tus mp3/ogg/wav sin copyright)
const fs = require('fs');
app.get('/music-list', (req, res) => {
  fs.readdir(path.join(__dirname, 'public', 'music'), (err, files) => {
    res.json(err ? [] : files.filter(f => /\.(mp3|ogg|wav|m4a)$/i.test(f)).map(f => '/music/' + encodeURIComponent(f)));
  });
});

// ── Panel de control (/admin) ────────────────────────────
const ADMIN_KEY = process.env.ADMIN_KEY || crypto.randomBytes(3).toString('hex');
const adminAuth = (req, res, next) =>
  (req.query.key === ADMIN_KEY ? next() : res.status(401).send('Clave incorrecta'));
const adminStatus = () => ({
  running: game.running, phase: game.phase, round: game.round, queue: game.queue.size,
  players: game.players.size, max: WORLD_CFG.MAX_PLAYERS, lobby: WORLD_CFG.LOBBY_SECONDS,
});
app.get('/admin', adminAuth, (req, res) => res.sendFile(path.join(__dirname, 'admin.html')));
app.get('/admin/api/status', adminAuth, (req, res) => res.json(adminStatus()));
app.post('/admin/api/:action', adminAuth, express.json(), (req, res) => {
  const d = Number(req.body && req.body.delta) || 0;
  switch (req.params.action) {
    case 'reset':  game.reset(); break;
    case 'pause':  game.pause(); break;
    case 'resume': game.start(); break;
    case 'max':    game.setConfig({ max:   WORLD_CFG.MAX_PLAYERS   + d }); break;
    case 'lobby':  game.setConfig({ lobby: WORLD_CFG.LOBBY_SECONDS + d }); break;
    default: return res.status(400).send('Acción desconocida');
  }
  res.json(adminStatus());
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// ── Game engine ─────────────────────────────────────────
const game = new GameEngine();

// Cuando el engine quiere mandar algo al frontend
game.onBroadcast = (event) => {
  broadcast(event);
};

// ── WebSocket ────────────────────────────────────────────
function broadcast(data) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(client => {
    if (client.readyState === 1) client.send(msg);
  });
}

wss.on('connection', (ws) => {
  console.log('[WS] Cliente conectado');

  // Mandar estado actual del juego al cliente nuevo
  ws.send(JSON.stringify({ type: 'game_state', build: BUILD, state: game.getState() }));

  ws.on('message', (raw) => {
    let m; try { m = JSON.parse(raw); } catch (_) { return; }
    if (m && m.type === 'view' && game.setView(m.aspect, m.area)) {
      broadcast({ type: 'game_state', state: game.getState() });
    }
  });

  ws.on('close', () => console.log('[WS] Cliente desconectado'));
});

// ── TikTok Live ──────────────────────────────────────────
// tiktok-live-connector v2 es ESM → se carga con import() dinámico desde CommonJS.
let tiktok = null;
const short = (e) => String((e && e.message) || e).slice(0, 200);

async function initTikTok() {
  const { TikTokLiveConnection } = await import('tiktok-live-connector');
  tiktok = new TikTokLiveConnection(TIKTOK_USERNAME, {
    signApiKey: SIGN_API_KEY || undefined,
    processInitialData: false,
  });

  tiktok.on('connected', () => {
    console.log(`[TikTok] Conectado al live de @${TIKTOK_USERNAME}`);
    game.start();
  });

  tiktok.on('disconnected', () => {
    console.log('[TikTok] Desconectado, intentando reconectar...');
    game.pause();
    connectLoop();
  });

  tiktok.on('error', (err) => {
    console.error('[TikTok] Error:', short(err && (err.exception || err.info) || err));
  });

  // ── Eventos del live ───────────────────────────────────
  // Nuevo viewer se une
  tiktok.on('member', (d) => {
    const u = userOf(d); if (!u.userId) return;
    registerAvatar(u.userId, u.profilePictureUrl);
    game.handleJoin(u);
  });

  // Comentario
  tiktok.on('chat', (d) => {
    const c = chatOf(d); if (!c.userId) return;
    registerAvatar(c.userId, c.profilePictureUrl);
    game.handleComment(c);
  });

  // Gift
  tiktok.on('gift', (d) => {
    const g = giftOf(d); if (!g.userId) return;
    // Solo procesar cuando el streak termina (para evitar duplicados en gifts streak)
    if (g.giftType === 1 && !g.repeatEnd) return;
    registerAvatar(g.userId, g.profilePictureUrl);
    game.handleGift(g);
    // Agradecimiento por voz (lo reproduce la página en thanks.js)
    broadcast({ type: 'thanks', kind: 'gift', name: g.nickname || g.username, gift: g.giftName,
                count: g.repeatCount, diamonds: g.diamondCount * g.repeatCount });
  });

  // Nuevo seguidor (se evita repetir el agradecimiento al mismo usuario)
  const thankedFollowers = new Set();
  tiktok.on('follow', (d) => {
    const u = userOf(d); if (!u.userId || thankedFollowers.has(u.userId)) return;
    thankedFollowers.add(u.userId);
    console.log(`[TikTok] Nuevo seguidor: ${u.nickname || u.username}`);
    broadcast({ type: 'thanks', kind: 'follow', name: u.nickname || u.username });
  });

  // Likes (tap tap)
  tiktok.on('like', (d) => {
    const l = likeOf(d); if (!l.userId) return;
    game.handleLike(l);
  });

  // Share
  tiktok.on('share', (d) => {
    const u = userOf(d); if (!u.userId) return;
    game.handleShare({ userId: u.userId, username: u.username });
  });
}

// ── Conectar y arrancar ──────────────────────────────────
// Reintenta cada 5s hasta que el live esté activo (así puedes abrir la página
// en el celular ANTES de iniciar el live). OFFLINE=1 → modo bots para pruebas.
let connecting = false;
function connectLoop() {
  if (connecting) return;
  connecting = true;
  const attempt = () => {
    tiktok.connect().then(() => { connecting = false; }).catch((err) => {
      console.log(`[TikTok] Live de @${TIKTOK_USERNAME} no disponible (${short(err)}). Reintentando en 5s...`);
      setTimeout(attempt, 5000);
    });
  };
  attempt();
}

server.listen(PORT, () => {
  const nets = Object.values(require('os').networkInterfaces()).flat();
  const ips = nets.filter(n => n.family === 'IPv4' && !n.internal).map(n => n.address);
  console.log(`[Server] PC:      http://localhost:${PORT}`);
  ips.forEach(ip => console.log(`[Server] Celular: http://${ip}:${PORT}   (mismo Wi-Fi)`));
  console.log(`[Server] Admin:   http://localhost:${PORT}/admin?key=${ADMIN_KEY}`);

  if (process.env.OFFLINE === '1') {
    console.log('[Server] Modo offline (bots de prueba)');
    game.startOffline();
  } else {
    if (!SIGN_API_KEY) console.log('[TikTok] Aviso: falta EULER_KEY (API key gratis de eulerstream.com). Sin ella la firma puede fallar con error 403.');
    console.log(`[TikTok] Esperando el live de @${TIKTOK_USERNAME}...`);
    initTikTok().then(connectLoop).catch((e) => console.error('[TikTok] No se pudo cargar la librería:', short(e)));
  }
});
