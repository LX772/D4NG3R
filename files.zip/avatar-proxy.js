const https = require('https');
const http  = require('http');

// Cache en memoria: userId → { buffer, contentType, cachedAt }
const cache = new Map();
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutos

// URL por userId registrada cuando el jugador entra
const urlRegistry = new Map(); // userId → profilePictureUrl

function registerAvatar(userId, url) {
  if (url) urlRegistry.set(userId, url);
}

function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https') ? https : http;
    lib.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; TikTokBattle/1.0)',
      }
    }, (res) => {
      // Seguir redirects
      if (res.statusCode === 301 || res.statusCode === 302) {
        return fetchUrl(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => resolve({
        buffer:      Buffer.concat(chunks),
        contentType: res.headers['content-type'] || 'image/jpeg',
      }));
    }).on('error', reject);
  });
}

// Middleware de Express: GET /avatar/:userId
async function avatarMiddleware(req, res) {
  const { userId } = req.params;
  const url = urlRegistry.get(userId);

  if (!url) {
    return res.status(404).send('Avatar no registrado');
  }

  // Cache hit
  const cached = cache.get(userId);
  if (cached && Date.now() - cached.cachedAt < CACHE_TTL_MS) {
    res.setHeader('Content-Type', cached.contentType);
    res.setHeader('Cache-Control', 'public, max-age=600');
    return res.end(cached.buffer);
  }

  try {
    const { buffer, contentType } = await fetchUrl(url);
    cache.set(userId, { buffer, contentType, cachedAt: Date.now() });
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=600');
    res.end(buffer);
  } catch (err) {
    console.warn(`[Avatar] Error descargando ${userId}:`, err.message);
    res.status(502).send('Error descargando avatar');
  }
}

// Limpiar cache viejo cada 15 minutos
setInterval(() => {
  const now = Date.now();
  for (const [id, entry] of cache) {
    if (now - entry.cachedAt > CACHE_TTL_MS) cache.delete(id);
  }
}, 15 * 60 * 1000);

module.exports = { avatarMiddleware, registerAvatar };
