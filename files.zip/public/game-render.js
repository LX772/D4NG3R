// ═══════════════════════════════════════════════════════════════════════════
//  TikTok Battle — render
//  El servidor manda posiciones en un mundo lógico de 800x500; aquí se escala
//  a la pantalla, se interpola el movimiento y se animan golpes, daño y zona.
// ═══════════════════════════════════════════════════════════════════════════

let wsRef = null;
let viewTimer = null;

function connectWS() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const ws = new WebSocket(`${proto}://${location.host}`);
  wsRef = ws;
  ws.onopen    = () => { setStatus('ready', 'Conectado'); sendView(); };
  ws.onclose   = () => { setStatus('off', 'Reconectando...'); setTimeout(connectWS, 2000); };
  ws.onerror   = () => ws.close();
  ws.onmessage = (e) => handleMessage(JSON.parse(e.data));
}
// Pantalla siempre encendida (importante al transmitir desde el celular)
async function keepAwake() { try { await navigator.wakeLock.request('screen'); } catch (_) {} }
document.addEventListener('visibilitychange', () => { if (!document.hidden) { keepAwake(); setTimeout(() => sendView(), 200); } });
window.addEventListener('focus', () => setTimeout(() => sendView(), 200));
// Reafirma el tamaño mientras esta pantalla esté activa (el servidor solo lo aplica entre rondas)
setInterval(() => sendView(), 3000);
keepAwake();

let WORLD_W = 500, WORLD_H = 800; // el servidor lo adapta a la pantalla
const ATTACK_MS = 380;   // duración de la animación de golpe
const HIT_MS    = 240;   // duración del destello al recibir daño

const state = {
  players:   new Map(),
  running:   false,
  round:     1,
  winner:    null,
  phase:     'lobby',
  lobbyLeft: 0,
  waiting:   true,
  queue:     0,
  max:       20,
  zone:      { x: 250, y: 400, r: 470, toR: 470, status: 'waiting', timeLeft: 0, phase: 0, dps: 0 },
};

const vis          = new Map(); // userId → estado visual (posición suave, ángulo, timers de animación)
const avatarCache  = new Map();
const zoneView     = { r: 470, toR: 470 };
let   shake        = 0;

// Elementos creados por JS dentro de la arena
document.getElementById('arena-wrap').insertAdjacentHTML('beforeend', '<div id="gift-alert"></div><div id="countdown" class="hidden"></div>');
connectWS();
const canvas = document.getElementById('arena');
const ctx    = canvas.getContext('2d');
const view   = { s: 1, es: 1, ox: 0, oy: 0, dpr: 1, cw: 0, ch: 0 };
const cam    = { z: 1, cx: 250, cy: 400 };   // cámara con zoom suave

// Píxeles de pantalla por unidad de mundo que buscamos (personajes legibles)
const TARGET_SCALE = 0.85;
function sendView(force) {
  if (!force && (document.hidden || !document.hasFocus())) return;
  if (!wsRef || wsRef.readyState !== 1 || !view.cw || !view.ch) return;
  const area = (view.cw / TARGET_SCALE) * (view.ch / TARGET_SCALE);
  wsRef.send(JSON.stringify({ type: 'view', aspect: view.cw / view.ch, area }));
}

function resizeCanvas() {
  const wrap = document.getElementById('arena-wrap');
  const dpr  = Math.min(window.devicePixelRatio || 1, 2);
  const cw = wrap.clientWidth, ch = wrap.clientHeight;
  // Canvas nítido en pantallas retina; todo el dibujo sigue en px CSS
  canvas.width  = Math.round(cw * dpr);
  canvas.height = Math.round(ch * dpr);
  view.dpr = dpr;
  view.cw = cw; view.ch = ch;
  view.s  = Math.min(cw / WORLD_W, ch / WORLD_H);
  view.es = view.s * cam.z;
  view.ox = (cw - WORLD_W * view.s) / 2;
  view.oy = (ch - WORLD_H * view.s) / 2;
  clearTimeout(viewTimer);
  viewTimer = setTimeout(sendView, 300);
}
window.addEventListener('resize', resizeCanvas);
if (window.ResizeObserver) new ResizeObserver(() => {
  const w = document.getElementById('arena-wrap');
  if (w.clientWidth !== view.cw || w.clientHeight !== view.ch) resizeCanvas();
}).observe(document.getElementById('arena-wrap'));
window.addEventListener('orientationchange', () => setTimeout(resizeCanvas, 200));
resizeCanvas();

// Aplica el tamaño de mundo que manda el servidor
function applyWorld(w) {
  if (!w || (w.W === WORLD_W && w.H === WORLD_H)) return;
  const fx = w.W / WORLD_W, fy = w.H / WORLD_H;
  cam.cx *= fx; cam.cy *= fy; if (cam.tx !== undefined) { cam.tx *= fx; cam.ty *= fy; }
  WORLD_W = w.W; WORLD_H = w.H;
  mapCanvas = null; buildTorches();
  resizeCanvas();
}

const TIER_CFG = {
  villager: { body:'#7b8db0', dark:'#4a5878', armor:'#4a5878', blade:'#8090a0', head:'#c8a070', cape:null,      crown:false, shield:false },
  soldier:  { body:'#3bffb0', dark:'#1a6045', armor:'#2acc8c', blade:'#d0e8ff', head:'#c8a070', cape:'#1a8060', crown:false, shield:false },
  knight:   { body:'#3b9fff', dark:'#1a4880', armor:'#2a7acc', blade:'#e0f0ff', head:'#c8a070', cape:'#1a4880', crown:false, shield:true  },
  king:     { body:'#e8ff3b', dark:'#806800', armor:'#c8d820', blade:'#ffffc0', head:'#c8a070', cape:'#a06800', crown:true,  shield:true  },
};

const EFFECT_COLOR = {
  healed:   '#3bffb0',
  attacked: '#ff3b5c',
  bombed:   '#ff8c3b',
  shielded: '#3b9fff',
};

// ── Utilidades ────────────────────────────────────────────────────────────────

function wrapPi(a) {
  while (a >  Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function findPlayer(username) {
  for (const p of state.players.values()) {
    if (p.username === username || p.nickname === username) return p;
  }
  return null;
}

function byIdOrName(id, name) {
  return (id !== undefined && state.players.get(id)) || findPlayer(name);
}

// ── Estado visual por jugador ─────────────────────────────────────────────────

function getVis(p) {
  let v = vis.get(p.userId);
  if (!v) {
    v = {
      rx: p.x, ry: p.y,          // posición suavizada
      offx: 0, offy: 0,          // empujón al recibir un golpe
      angle: Math.random() * Math.PI * 2,
      walk: Math.random() * 10,  // fase de caminata
      speed: 0,
      attackAt: -1e9,
      hitAt: -1e9,
      deadAt: null,
      winAt: null,
      hpShown: p.hp,
      phase: Math.random() * 6,
    };
    vis.set(p.userId, v);
  }
  return v;
}

function startAttack(att, tgt) {
  if (!att) return;
  const v = getVis(att);
  v.attackAt = performance.now();
  if (tgt) {
    const tv = getVis(tgt);
    v.angle = Math.atan2(tv.ry - v.ry, tv.rx - v.rx); // la espada apunta al objetivo
  }
}

function startHit(tgt, from) {
  if (!tgt) return;
  const v = getVis(tgt);
  v.hitAt = performance.now();
  if (from) {
    const fv = getVis(from);
    const a  = Math.atan2(v.ry - fv.ry, v.rx - fv.rx);
    v.offx += Math.cos(a) * 5;   // empujón alejándose del atacante
    v.offy += Math.sin(a) * 5;
  }
}

function updateVis(p, dt, now) {
  const v = getVis(p);

  // Movimiento suave hacia la posición del servidor
  const k  = 1 - Math.exp(-dt * 10);
  const px = v.rx, py = v.ry;
  v.rx += (p.x - v.rx) * k;
  v.ry += (p.y - v.ry) * k;
  const sp = dt > 0 ? Math.hypot(v.rx - px, v.ry - py) / dt : 0;
  v.speed += (sp - v.speed) * Math.min(1, dt * 8);
  v.walk  += sp * dt * 0.22;

  // El empujón se disipa
  const decay = Math.exp(-dt * 9);
  v.offx *= decay; v.offy *= decay;

  if (p.alive) {
    // Apuntar: al enemigo objetivo, o al centro de la zona si está huyendo
    let tx = null, ty = null;
    if (p.flee) {
      tx = state.zone.x; ty = state.zone.y;
    } else if (p.tid !== null && p.tid !== undefined) {
      const t = state.players.get(p.tid);
      if (t && t.alive) {
        const tv = vis.get(t.userId);
        tx = tv ? tv.rx : t.x; ty = tv ? tv.ry : t.y;
      }
    }
    if (tx !== null) {
      const want = Math.atan2(ty - v.ry, tx - v.rx);
      v.angle += wrapPi(want - v.angle) * Math.min(1, dt * 9);
    }
  } else if (!v.deadAt) {
    v.deadAt = now;
  }

  // Barra de HP con "estela" que baja despacio
  const target = p.alive ? p.hp : 0;
  if (v.hpShown > target) {
    v.hpShown += (target - v.hpShown) * Math.min(1, dt * 4);
    if (v.hpShown - target < 0.5) v.hpShown = target;
  } else {
    v.hpShown = target;
  }
  return v;
}

function loadAvatar(userId) {
  if (avatarCache.has(userId)) return;
  avatarCache.set(userId, 'loading');
  const img = new Image();
  img.onload  = () => avatarCache.set(userId, img);
  img.onerror = () => avatarCache.set(userId, 'error');
  img.src = `/avatar/${userId}`;
}

// ── Pixel helpers ─────────────────────────────────────────────────────────────

const S = 3; // tamaño de "pixel" del sprite en unidades del mundo

function pp(x, y, color) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x) * S, Math.round(y) * S, S, S);
}

function pr(x, y, w, h, color) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x) * S, Math.round(y) * S, w * S, h * S);
}

// ── Sprite top-down ───────────────────────────────────────────────────────────
// o = { swordAng, baseAngle, punch, bob, walkBob, alpha, effect, celebrate, frame }

function drawSprite(px, py, tier, o) {
  const t  = TIER_CFG[tier] || TIER_CFG.villager;
  const cx = Math.round(px / S);
  const oy = Math.round(py / S) + o.walkBob + Math.round(o.bob);
  const swordAng = o.swordAng;

  ctx.globalAlpha = Math.max(0, o.alpha);

  if (o.effect) {
    ctx.shadowColor = EFFECT_COLOR[o.effect] || '#fff';
    ctx.shadowBlur  = 12;
  }

  // Sombra en el suelo
  ctx.globalAlpha = Math.max(0, o.alpha * 0.4);
  ctx.fillStyle   = '#000';
  ctx.beginPath();
  ctx.ellipse(cx * S, (oy + 5) * S, 9 * S, 4 * S, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = Math.max(0, o.alpha);

  // Capa
  if (t.cape) {
    pr(cx - 3, oy - 1, 6, 7, t.cape + 'aa');
    pr(cx - 4, oy,     2, 5, t.cape + '66');
    pr(cx + 2, oy,     2, 5, t.cape + '66');
  }

  // Cuerpo
  pr(cx - 3, oy - 2, 6, 8, t.armor);
  pr(cx - 2, oy - 1, 4, 6, t.body);

  // Hombreras
  if (tier !== 'villager') {
    pr(cx - 4, oy - 1, 2, 3, t.armor);
    pr(cx + 2, oy - 1, 2, 3, t.armor);
  }

  // Detalle de pecho (knight+)
  if (tier === 'knight' || tier === 'king') {
    pp(cx, oy - 1, t.dark); pp(cx, oy, t.dark); pp(cx, oy + 1, t.dark);
    pr(cx - 2, oy + 2, 4, 1, t.dark);
  }

  // Borde dorado (king)
  if (tier === 'king') {
    pr(cx - 3, oy - 2, 6, 1, t.blade);
    pp(cx - 3, oy + 5, t.blade); pp(cx + 2, oy + 5, t.blade);
  }

  // Cabeza
  const hx = cx, hy = oy - 3;
  pr(hx - 2, hy - 2, 4, 5, t.head);
  if (tier === 'villager') {
    pr(hx - 2, hy - 2, 4, 2, '#5a3820');
  } else if (tier === 'soldier') {
    pr(hx - 2, hy - 2, 4, 1, t.dark);
    pr(hx - 3, hy - 1, 6, 1, t.dark);
  } else if (tier === 'knight') {
    pr(hx - 2, hy - 2, 4, 2, t.dark);
    pp(hx - 3, hy - 1, t.dark); pp(hx + 2, hy - 1, t.dark);
    pr(hx - 1, hy, 2, 1, '#1a2535');
  } else if (tier === 'king') {
    pr(hx - 2, hy - 2, 4, 2, t.dark);
    pp(hx - 2, hy - 4, t.blade); pp(hx, hy - 5, t.blade); pp(hx + 1, hy - 4, t.blade);
    pr(hx - 2, hy - 3, 4, 1, t.blade);
    pp(hx, hy - 2, '#ff3b5c');
  }
  pp(hx - 1, hy, '#1a1a2e'); pp(hx + 1, hy, '#1a1a2e'); // ojos

  // Escudo (knight+) — lado opuesto a la espada
  if (t.shield) {
    const shAng = swordAng + Math.PI;
    const shx   = cx + Math.round(Math.cos(shAng) * 5);
    const shy   = oy + Math.round(Math.sin(shAng) * 5);
    pr(shx - 1, shy - 1, 2, 3, tier === 'king' ? t.blade : t.dark);
    pp(shx, shy, tier === 'king' ? '#ff3b5c' : '#3b9fff');
  }

  if (tier !== 'villager') {
    // Espada (soldier+)
    const sr  = 6;
    const sx  = cx + Math.round(Math.cos(swordAng) * sr);
    const sy2 = oy + Math.round(Math.sin(swordAng) * sr);
    for (let i = 0; i < 5; i++) {
      const bx = Math.round(sx + Math.cos(swordAng) * i);
      const by = Math.round(sy2 + Math.sin(swordAng) * i);
      pp(bx, by, i < 2 ? '#8b7355' : (tier === 'king' ? '#e8ff3b' : t.blade));
    }
    pp(Math.round(sx + Math.cos(swordAng + Math.PI / 2)), Math.round(sy2 + Math.sin(swordAng + Math.PI / 2)), '#8b7355');
    pp(Math.round(sx - Math.cos(swordAng + Math.PI / 2)), Math.round(sy2 - Math.sin(swordAng + Math.PI / 2)), '#8b7355');
  } else {
    // El aldeano pelea con los puños: el puño sale disparado hacia el objetivo
    const reach = 5 + o.punch * 4;
    const fx = cx + Math.round(Math.cos(o.baseAngle) * reach);
    const fy = oy + Math.round(Math.sin(o.baseAngle) * reach);
    pr(fx - 1, fy - 1, 2, 2, t.head);
  }

  // Partículas de celebración
  if (o.celebrate) {
    ['#e8ff3b', '#ff3b5c', '#3bffb0', '#3b9fff'].forEach((c, i) => {
      const a2 = o.frame * 0.15 + i * Math.PI / 2;
      const r2 = 8 + Math.sin(o.frame * 0.1 + i) * 2;
      pp(Math.round(cx + Math.cos(a2) * r2), Math.round(oy + Math.sin(a2) * r2), c);
    });
  }

  ctx.shadowBlur  = 0;
  ctx.shadowColor = 'transparent';
  ctx.globalAlpha = 1;
}

// ── Dibujar jugador completo ──────────────────────────────────────────────────

// Los personajes escalan con la pantalla: nunca más pequeños de lo legible
function playerBoost() { return Math.max(1, Math.min(1.7, 0.85 / (view.es || view.s))); }

function drawPlayer(p, now) {
  const v = vis.get(p.userId);
  const k = playerBoost();
  if (k <= 1.02) return drawPlayerInner(p, now);
  const cx = v.rx + v.offx, cy = v.ry + v.offy;
  ctx.save();
  ctx.translate(cx, cy); ctx.scale(k, k); ctx.translate(-cx, -cy);
  drawPlayerInner(p, now);
  ctx.restore();
}

function drawPlayerInner(p, now) {
  const v     = vis.get(p.userId);
  const alive = p.alive;
  const tc    = TIER_CFG[p.tier || 'villager'];
  const many  = state.players.size > 60; // con mucha gente, sin glow para ir fluido

  // Golpe: embestida hacia el objetivo
  const at        = now - v.attackAt;
  const attacking = at >= 0 && at < ATTACK_MS;
  const ap        = attacking ? at / ATTACK_MS : 0;
  const lunge     = attacking ? Math.sin(ap * Math.PI) * 5 : 0;

  const x = v.rx + v.offx + Math.cos(v.angle) * lunge;
  const y = v.ry + v.offy + Math.sin(v.angle) * lunge;

  // Ángulo de la espada según la animación
  let swordAng = v.angle;
  let bob = 0, walkBob = 0;
  if (attacking) {
    // preparación hacia atrás → tajo rápido → recuperación
    const swing = ap < 0.25 ? -(ap / 0.25) * 0.9
                : ap < 0.60 ? -0.9 + ((ap - 0.25) / 0.35) * 2.4
                :             1.5 * (1 - (ap - 0.60) / 0.40);
    swordAng = v.angle + swing;
  } else if (v.speed > 8) {
    swordAng = v.angle + Math.sin(v.walk * 2) * 0.35;
    walkBob  = Math.sin(v.walk * 2) > 0.5 ? -1 : 0;
  } else {
    swordAng = v.angle + Math.sin(now * 0.004 + v.phase) * 0.12;
  }

  // Muerte / victoria
  let alpha = 1;
  if (!alive) {
    const dp = v.deadAt ? Math.min(1, (now - v.deadAt) / 600) : 1;
    alpha    = 0.9 - dp * 0.65;
    swordAng = v.angle + dp * Math.PI * 0.8;
  } else if (v.winAt) {
    bob      = -Math.abs(Math.sin((now - v.winAt) * 0.009)) * 4;
    swordAng = v.angle + Math.sin((now - v.winAt) * 0.009) * Math.PI * 0.6;
  }

  const ht    = now - v.hitAt;
  const flash = ht >= 0 && ht < HIT_MS ? 1 - ht / HIT_MS : 0;

  // Anillo rojo pulsante si está fuera de la zona (recibe daño de zona)
  if (alive && state.phase === 'battle' && state.zone.phase > 0) {
    const out = Math.hypot(v.rx - state.zone.x, v.ry - state.zone.y) > zoneView.r;
    if (out) {
      ctx.globalAlpha = 0.35 + Math.sin(now * 0.012) * 0.25;
      ctx.strokeStyle = '#ff3b5c';
      ctx.lineWidth   = 2;
      ctx.beginPath();
      ctx.ellipse(x, y + 15, 16, 7, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  drawSprite(x, y, p.tier || 'villager', {
    swordAng, bob, walkBob, alpha,
    baseAngle: v.angle,
    punch:     attacking ? Math.sin(ap * Math.PI) : 0,
    effect:    alive && !many ? p.effect : null,
    celebrate: alive && !!v.winAt,
    frame:     v.winAt ? (now - v.winAt) / 16 : 0,
  });

  // Destello al recibir daño
  if (flash > 0 && alive) {
    ctx.globalAlpha = flash * 0.6;
    ctx.fillStyle   = '#ffffff';
    ctx.beginPath();
    ctx.arc(x, y, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  // Arco del tajo (la "estela" del golpe)
  if (attacking && ap > 0.2 && ap < 0.8) {
    ctx.globalAlpha = Math.max(0, 1 - (ap - 0.2) / 0.6) * 0.9;
    ctx.strokeStyle = p.tier === 'villager' ? '#ffffff' : tc.blade;
    ctx.lineWidth   = 4;
    ctx.lineCap     = 'round';
    ctx.beginPath();
    ctx.arc(x, y, 24, v.angle - 0.9, swordAng, false);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  // Avatar (cabeza) encima del sprite
  const avatar = avatarCache.get(p.userId);
  const headR  = 11;
  const headX  = x;
  const headY  = y - 20;
  if (avatar && avatar !== 'loading' && avatar !== 'error') {
    ctx.save();
    ctx.globalAlpha = alive ? 1 : 0.3;
    ctx.beginPath();
    ctx.arc(headX, headY, headR, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(avatar, headX - headR, headY - headR, headR * 2, headR * 2);
    ctx.restore();
    ctx.strokeStyle = tc.body;
    ctx.lineWidth   = 2;
    ctx.globalAlpha = alive ? 1 : 0.3;
    ctx.beginPath();
    ctx.arc(headX, headY, headR, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  } else if (p.profilePictureUrl) {
    loadAvatar(p.userId);
  }

  // Los eliminados dejan solo la calavera (sin barra ni nick) para no ensuciar
  if (!alive && v.deadAt && now - v.deadAt > 1500) {
    ctx.font = '14px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.globalAlpha = 0.6; ctx.fillText('💀', x, y - 2);
    ctx.globalAlpha = 1; ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
    return;
  }

  if (!alive) {
    ctx.font         = '14px sans-serif';
    ctx.textBaseline = 'middle';
    ctx.fillText('💀', x, y - 6);
  }

  ctx.textBaseline = 'alphabetic';
  ctx.textAlign    = 'left';
  ctx.globalAlpha  = 1;
}

// ── Partículas, textos flotantes, ondas de choque ─────────────────────────────

const particles  = [];
const floaters   = [];
const shockwaves = [];

function spawnParticles(x, y, color, count = 8) {
  for (let i = 0; i < count; i++) {
    const angle = (Math.PI * 2 / count) * i + Math.random() * 0.5;
    const speed = 1.5 + Math.random() * 3;
    particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, color, size: 2 + Math.random() * 3, life: 1 });
  }
}

function spawnSpark(x, y, color) {
  for (let i = 0; i < 5; i++) {
    const a = Math.random() * Math.PI * 2, s = 1 + Math.random() * 2.5;
    particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, color, size: 1.5 + Math.random() * 1.5, life: 0.6 });
  }
}

function spawnFloater(x, y, text, color, size = 13) {
  floaters.push({ x: x + (Math.random() - 0.5) * 10, y, text, color, size, vy: -0.9, life: 1 });
}

function spawnShockwave(x, y, color) {
  shockwaves.push({ x, y, r: 10, life: 1, color });
}

function updateAndDrawEffects(dt) {
  // Ondas de choque
  for (let i = shockwaves.length - 1; i >= 0; i--) {
    const w = shockwaves[i];
    w.r += dt * 520; w.life -= dt * 1.3;
    if (w.life <= 0) { shockwaves.splice(i, 1); continue; }
    ctx.globalAlpha = w.life * 0.8;
    ctx.strokeStyle = w.color;
    ctx.lineWidth   = 5 * w.life + 1;
    ctx.beginPath(); ctx.arc(w.x, w.y, w.r, 0, Math.PI * 2); ctx.stroke();
  }

  // Partículas
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x += p.vx; p.y += p.vy; p.vy += 0.07;
    p.life -= 0.025;
    if (p.life <= 0) { particles.splice(i, 1); continue; }
    ctx.globalAlpha = p.life;
    ctx.fillStyle   = p.color;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
  }

  // Textos flotantes
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (let i = floaters.length - 1; i >= 0; i--) {
    const f = floaters[i];
    f.y += f.vy; f.life -= 0.018;
    if (f.life <= 0) { floaters.splice(i, 1); continue; }
    ctx.globalAlpha = Math.min(1, f.life * 1.5);
    ctx.font        = `bold ${f.size}px Inter, sans-serif`;
    ctx.lineWidth   = 3;
    ctx.strokeStyle = 'rgba(0,0,0,.7)';
    ctx.strokeText(f.text, f.x, f.y);
    ctx.fillStyle   = f.color;
    ctx.fillText(f.text, f.x, f.y);
  }
  ctx.globalAlpha  = 1;
  ctx.textAlign    = 'left';
  ctx.textBaseline = 'alphabetic';
}

// ── Arena y zona ──────────────────────────────────────────────────────────────

// ── Mapa: arena de piedra con muros y antorchas ───────────────────────────────

const WALL = 14; // grosor visual del muro (los jugadores nunca lo pisan)
let TORCHES = [];
function buildTorches() {
  const T = [];
  const nx = Math.max(2, Math.round(WORLD_W / 250)), ny = Math.max(3, Math.round(WORLD_H / 265));
  for (let i = 0; i < nx; i++) {
    const x = WORLD_W * (i + 0.5) / nx;
    T.push([x, 7], [x, WORLD_H - 7]);
  }
  for (let i = 0; i < ny; i++) {
    const y = WORLD_H * (i + 0.5) / ny;
    T.push([7, y], [WORLD_W - 7, y]);
  }
  TORCHES = T;
}
buildTorches();

function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// Se dibuja una sola vez en un canvas aparte (el mapa es siempre el mismo)
function buildMap() {
  const SC = 2;
  const c  = document.createElement('canvas');
  c.width  = WORLD_W * SC;
  c.height = WORLD_H * SC;
  const g  = c.getContext('2d');
  g.scale(SC, SC);
  const rnd = mulberry32(1337);
  const cx = WORLD_W / 2, cy = WORLD_H / 2;

  // Losas de piedra
  g.fillStyle = '#0f121c';
  g.fillRect(0, 0, WORLD_W, WORLD_H);
  const T = 50;
  for (let ty = 0; ty < WORLD_H / T; ty++) {
    for (let tx = 0; tx < WORLD_W / T; tx++) {
      const s = rnd();
      g.fillStyle = `rgb(${24 + s * 12 | 0},${29 + s * 12 | 0},${44 + s * 14 | 0})`;
      g.fillRect(tx * T + 1, ty * T + 1, T - 2, T - 2);
      g.fillStyle = 'rgba(255,255,255,0.035)';
      g.fillRect(tx * T + 1, ty * T + 1, T - 2, 2);
      g.fillRect(tx * T + 1, ty * T + 1, 2, T - 2);
      g.fillStyle = 'rgba(0,0,0,0.25)';
      g.fillRect(tx * T + 1, ty * T + T - 3, T - 2, 2);
    }
  }

  // Musgo
  for (let i = 0; i < 16; i++) {
    const mx = rnd() * WORLD_W, my = rnd() * WORLD_H, mr = 18 + rnd() * 34;
    const gr = g.createRadialGradient(mx, my, 0, mx, my, mr);
    gr.addColorStop(0, 'rgba(59,200,140,0.10)');
    gr.addColorStop(1, 'rgba(59,200,140,0)');
    g.fillStyle = gr;
    g.beginPath(); g.arc(mx, my, mr, 0, Math.PI * 2); g.fill();
  }

  // Grietas
  g.strokeStyle = 'rgba(0,0,0,0.45)';
  g.lineWidth = 1.2;
  for (let i = 0; i < 26; i++) {
    let x = rnd() * WORLD_W, y = rnd() * WORLD_H;
    g.beginPath(); g.moveTo(x, y);
    const n = 3 + (rnd() * 3 | 0);
    for (let k = 0; k < n; k++) { x += (rnd() - 0.5) * 34; y += (rnd() - 0.5) * 34; g.lineTo(x, y); }
    g.stroke();
  }

  // Piedritas sueltas
  for (let i = 0; i < 46; i++) {
    const x = rnd() * WORLD_W, y = rnd() * WORLD_H, w = 2 + rnd() * 4;
    g.fillStyle = `rgba(${90 + rnd() * 40 | 0},${96 + rnd() * 40 | 0},${115 + rnd() * 40 | 0},0.35)`;
    g.beginPath(); g.ellipse(x, y, w, w * 0.7, rnd() * 3, 0, Math.PI * 2); g.fill();
  }

  // Círculo central de arena con emblema
  const sand = g.createRadialGradient(cx, cy, 10, cx, cy, 120);
  sand.addColorStop(0, 'rgba(214,170,96,0.26)');
  sand.addColorStop(1, 'rgba(214,170,96,0)');
  g.fillStyle = sand;
  g.beginPath(); g.arc(cx, cy, 120, 0, Math.PI * 2); g.fill();

  g.strokeStyle = 'rgba(232,255,59,0.16)';
  g.lineWidth = 2;
  [46, 96, 170].forEach(rad => { g.beginPath(); g.arc(cx, cy, rad, 0, Math.PI * 2); g.stroke(); });
  g.lineWidth = 3;
  g.lineCap = 'round';
  [[-1, -1, 1, 1], [1, -1, -1, 1]].forEach(([x1, y1, x2, y2]) => {   // dos espadas cruzadas
    g.beginPath(); g.moveTo(cx + x1 * 26, cy + y1 * 26); g.lineTo(cx + x2 * 26, cy + y2 * 26); g.stroke();
  });

  // Marcas de las 4 direcciones (runas)
  g.fillStyle = 'rgba(232,255,59,0.12)';
  for (let i = 0; i < 8; i++) {
    const a = i * Math.PI / 4;
    g.beginPath(); g.arc(cx + Math.cos(a) * 170, cy + Math.sin(a) * 170, 4, 0, Math.PI * 2); g.fill();
  }

  // Muros
  g.fillStyle = '#242b40';
  g.fillRect(0, 0, WORLD_W, WALL);
  g.fillRect(0, WORLD_H - WALL, WORLD_W, WALL);
  g.fillRect(0, 0, WALL, WORLD_H);
  g.fillRect(WORLD_W - WALL, 0, WALL, WORLD_H);
  g.strokeStyle = 'rgba(0,0,0,0.45)';
  g.lineWidth = 1;
  for (let x = 0; x < WORLD_W; x += 28) {
    [[x, 0], [x + 14, WORLD_H - WALL]].forEach(([bx, by]) => { g.beginPath(); g.moveTo(bx, by); g.lineTo(bx, by + WALL); g.stroke(); });
  }
  for (let y = 0; y < WORLD_H; y += 28) {
    [[0, y], [WORLD_W - WALL, y + 14]].forEach(([bx, by]) => { g.beginPath(); g.moveTo(bx, by); g.lineTo(bx + WALL, by); g.stroke(); });
  }
  g.strokeStyle = 'rgba(0,0,0,0.6)';
  g.beginPath(); g.moveTo(WALL, WALL); g.lineTo(WORLD_W - WALL, WALL); g.lineTo(WORLD_W - WALL, WORLD_H - WALL);
  g.lineTo(WALL, WORLD_H - WALL); g.closePath(); g.stroke();

  // Sombra interior del muro y viñeta general
  const vg = g.createRadialGradient(cx, cy, 220, cx, cy, 500);
  vg.addColorStop(0, 'rgba(0,0,0,0)');
  vg.addColorStop(1, 'rgba(0,0,0,0.55)');
  g.fillStyle = vg;
  g.fillRect(0, 0, WORLD_W, WORLD_H);
  return c;
}

let mapCanvas = null;

function drawWorldBackground(now) {
  if (!mapCanvas) mapCanvas = buildMap();
  ctx.drawImage(mapCanvas, 0, 0, WORLD_W, WORLD_H);

  // Antorchas con llama que parpadea
  TORCHES.forEach(([tx, ty], i) => {
    const f  = 0.85 + Math.sin(now * 0.011 + i * 1.7) * 0.10 + Math.sin(now * 0.027 + i) * 0.05;
    const gr = ctx.createRadialGradient(tx, ty, 0, tx, ty, 95 * f);
    gr.addColorStop(0, 'rgba(255,170,70,0.26)');
    gr.addColorStop(1, 'rgba(255,170,70,0)');
    ctx.fillStyle = gr;
    ctx.fillRect(tx - 100, ty - 100, 200, 200);
    ctx.fillStyle = '#ff9a3c';
    ctx.beginPath(); ctx.arc(tx, ty, 3.4 * f, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffe08a';
    ctx.beginPath(); ctx.arc(tx, ty, 1.7 * f, 0, Math.PI * 2); ctx.fill();
  });
}

function drawZone(now, dt) {
  const z = state.zone;
  zoneView.r   += (z.r   - zoneView.r)   * Math.min(1, dt * 8);
  zoneView.toR += (z.toR - zoneView.toR) * Math.min(1, dt * 8);
  if (state.phase !== 'battle') return;

  const shrinking = z.status === 'shrinking';

  // Todo lo que queda fuera de la zona se tiñe de rojo
  ctx.beginPath();
  ctx.rect(0, 0, WORLD_W, WORLD_H);
  ctx.arc(z.x, z.y, zoneView.r, 0, Math.PI * 2);
  ctx.fillStyle = `rgba(255,40,80,${shrinking ? 0.20 + Math.sin(now * 0.008) * 0.04 : 0.15})`;
  ctx.fill('evenodd');

  // Próxima zona (círculo blanco punteado)
  if (zoneView.toR < zoneView.r - 2) {
    ctx.save();
    ctx.setLineDash([8, 8]);
    ctx.lineDashOffset = -now * 0.02;
    ctx.strokeStyle = 'rgba(255,255,255,0.65)';
    ctx.lineWidth   = 2;
    ctx.beginPath(); ctx.arc(z.x, z.y, zoneView.toR, 0, Math.PI * 2); ctx.stroke();
    ctx.restore();
  }

  // Borde de la zona actual
  ctx.save();
  ctx.shadowColor = '#ff3b5c';
  ctx.shadowBlur  = shrinking ? 18 : 10;
  ctx.strokeStyle = '#ff3b5c';
  ctx.lineWidth   = shrinking ? 4 : 3;
  if (shrinking) { ctx.setLineDash([14, 8]); ctx.lineDashOffset = -now * 0.05; }
  ctx.beginPath(); ctx.arc(z.x, z.y, zoneView.r, 0, Math.PI * 2); ctx.stroke();
  ctx.restore();
}

// Cartel superior sobre el canvas (en pantalla, no en el mundo)
function drawPill(text, color) {
  const fs = view.cw < 500 ? 13 : 15;
  ctx.font = `700 ${fs}px Rajdhani, Inter, sans-serif`;
  // En pantallas angostas el cartel se parte para no salirse
  let w = ctx.measureText(text).width + 32; const h = 30;
  if (w > view.cw - 16) { const k = (view.cw - 16) / w; ctx.font = `700 ${Math.max(9, fs * k)}px Rajdhani, Inter, sans-serif`; w = view.cw - 16; }
  const x = (view.cw - w) / 2, y = 12;
  ctx.fillStyle   = 'rgba(10,12,16,.82)';
  ctx.strokeStyle = color;
  ctx.lineWidth   = 1.5;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, 8); else ctx.rect(x, y, w, h);
  ctx.fill(); ctx.stroke();
  ctx.fillStyle    = color;
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, view.cw / 2, y + h / 2 + 1);
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
}

function drawCanvasHUD() {
  const z = state.zone;
  if (state.phase === 'lobby') {
    const alive = Array.from(state.players.values()).filter(p => p.alive).length;
    const q = state.queue > 0 ? ` · 👥 ${state.queue} en cola` : '';
    if (state.waiting) drawPill(`⏳ Esperando jugadores… ${alive}/${state.max} (mín. 2) — ¡comenta para unirte!${q}`, '#e8ff3b');
    else               drawPill(`⏳ Jugadores ${alive}/${state.max} · empieza en ${state.lobbyLeft}s${q}`, '#e8ff3b');
  } else if (state.phase === 'battle') {
    if (z.status === 'waiting')        drawPill(`⚠️ La zona se cierra en ${z.timeLeft}s`, '#ffffff');
    else if (z.status === 'shrinking') drawPill(`🔴 ¡ZONA CERRÁNDOSE! ${z.timeLeft}s · −${z.dps} HP/s fuera`, '#ff3b5c');
    else                               drawPill(`☠️ ZONA FINAL · −${z.dps} HP/s fuera`, '#ff3b5c');
  }
}


// ── Capa de etiquetas (barra de vida + nick), sin solaparse ───────────────────
// Se dibuja después de todos los personajes; si dos etiquetas chocan, la de
// abajo se desplaza para que todos los nicks se lean.
function getLeader() {
  if (state.phase !== 'battle' && state.phase !== 'over') return null;
  let best = null;
  state.players.forEach(p => {
    if (!p.alive || !(p.kills > 0)) return;
    if (!best || p.kills > best.kills || (p.kills === best.kills && p.hp > best.hp)) best = p;
  });
  return best;
}

function drawLabels(alive, dt, now) {
  const es = view.es || view.s, k = playerBoost();
  const fs = Math.max(10, 12 / es), barH = Math.max(4, 5 / es), barW = 40 * k;
  ctx.font = `600 ${fs}px Inter, sans-serif`;
  const leader = getLeader();

  // 1) medir y colocar (de arriba abajo en pantalla)
  const items = alive.map(p => {
    const v = vis.get(p.userId);
    const name = p.nickname || p.username;
    const tw = ctx.measureText(name).width + 8;
    const w  = Math.max(barW, tw);
    const h  = barH + 2 + fs + 3 + (p.armor > 0 ? fs : 0);
    return { p, v, name, w, h, x: v.rx + v.offx, y: v.ry + v.offy + 22 * k };
  }).sort((a, b) => a.y - b.y);

  const placed = [];
  items.forEach(it => {
    let off = 0;
    for (let tries = 0; tries < 8; tries++) {
      const top = it.y + off;
      const hit = placed.find(o => Math.abs(o.x - it.x) < (o.w + it.w) / 2 && top < o.top + o.h && top + it.h > o.top);
      if (!hit) break;
      off = hit.top + hit.h + 1 - it.y;
    }
    it.v.lblOff = (it.v.lblOff ?? off);
    it.v.lblOff += (off - it.v.lblOff) * Math.min(1, dt * 10);
    placed.push({ x: it.x, top: it.y + off, w: it.w, h: it.h });
  });

  // 2) dibujar
  ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  items.forEach(({ p, v, name, w, h, x, y }) => {
    const top  = y + v.lblOff;
    const isL  = leader && leader.userId === p.userId;
    const barX = x - barW / 2;

    // fondo suave para que el nick se lea sobre cualquier zona del mapa
    ctx.fillStyle = 'rgba(7,8,12,0.5)';
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(x - w / 2, top - 1, w, h - 1, 4); else ctx.rect(x - w / 2, top - 1, w, h - 1);
    ctx.fill();

    // barra de vida con estela
    ctx.fillStyle = '#1e2535';
    ctx.fillRect(barX, top, barW, barH);
    const ratio = Math.max(0, p.hp / p.maxHp);
    const trail = Math.max(0, v.hpShown / p.maxHp);
    if (trail > ratio) { ctx.fillStyle = '#ffffff'; ctx.fillRect(barX, top, barW * trail, barH); }
    ctx.fillStyle = ratio > 0.5 ? '#3bffb0' : ratio > 0.25 ? '#ff8c3b' : '#ff3b5c';
    ctx.fillRect(barX, top, barW * ratio, barH);

    // nick
    ctx.font = `600 ${fs}px Inter, sans-serif`;
    ctx.fillStyle = isL ? '#ffd84a' : 'rgba(225,235,250,0.95)';
    ctx.fillText(name, x, top + barH + 2);
    if (p.armor > 0) {
      ctx.fillStyle = '#3b9fff';
      ctx.font = `bold ${fs * 0.92}px Inter, sans-serif`;
      ctx.fillText(`🛡${p.armor}%`, x, top + barH + 2 + fs + 1);
    }

    // corona y aura del líder (más kills) o del ganador
    if (isL || v.winAt) {
      const bob = Math.sin(now * 0.006 + v.phase) * 2;
      ctx.textBaseline = 'middle';
      ctx.font = `${Math.max(16, 20 / es)}px sans-serif`;
      ctx.fillText('👑', x, v.ry + v.offy - 32 * k + bob);
      ctx.textBaseline = 'top';
    }
  });
  ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
}

// Anillo dorado bajo los pies del líder (va debajo de los personajes)
function drawLeaderAura(now) {
  const l = getLeader();
  if (!l) return;
  const v = vis.get(l.userId); if (!v) return;
  const k = playerBoost(), pulse = 1 + Math.sin(now * 0.006) * 0.06;
  ctx.save();
  ctx.strokeStyle = 'rgba(255,216,74,0.9)'; ctx.lineWidth = 2.5 / (view.es || view.s);
  ctx.shadowColor = '#ffd84a'; ctx.shadowBlur = 14;
  ctx.beginPath(); ctx.ellipse(v.rx + v.offx, v.ry + v.offy + 14 * k, 24 * k * pulse, 9 * k * pulse, 0, 0, Math.PI * 2); ctx.stroke();
  ctx.restore();
}

// ── Cámara: con pocos vivos acerca la acción; al ganar, enfoca al ganador ─────
function updateCamera(dt) {
  const alive = Array.from(state.players.values()).filter(p => p.alive);
  let zt = 1, tx = WORLD_W / 2, ty = WORLD_H / 2;
  const fightOn = (state.phase === 'battle' || state.phase === 'over') && alive.length >= 1 && alive.length <= 4;
  if (fightOn) {
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    alive.forEach(p => { const v = vis.get(p.userId); if (!v) return; x0 = Math.min(x0, v.rx); x1 = Math.max(x1, v.rx); y0 = Math.min(y0, v.ry); y1 = Math.max(y1, v.ry); });
    if (x0 < 1e8) {
      const pad = 130;
      const nw = (x1 - x0) + pad * 2, nh = (y1 - y0) + pad * 2;
      const zMax = alive.length === 1 ? 1.4 : 1.8;      // el ganador: zoom suave
      zt = Math.max(1, Math.min(zMax, view.cw / (view.s * nw), view.ch / (view.s * nh)));
      tx = (x0 + x1) / 2; ty = (y0 + y1) / 2;
    }
  }
  // Doble suavizado: el objetivo se filtra (ignora saltos al morir alguien) y la cámara lo sigue
  if (cam.tz === undefined) { cam.tz = 1; cam.tx = tx; cam.ty = ty; }
  const kt = 1 - Math.exp(-dt * 1.6);
  cam.tz += (zt - cam.tz) * kt; cam.tx += (tx - cam.tx) * kt; cam.ty += (ty - cam.ty) * kt;

  const vw = view.cw / (view.s * cam.tz), vh = view.ch / (view.s * cam.tz);
  const cx = vw >= WORLD_W ? WORLD_W / 2 : Math.max(vw / 2, Math.min(WORLD_W - vw / 2, cam.tx));
  const cy = vh >= WORLD_H ? WORLD_H / 2 : Math.max(vh / 2, Math.min(WORLD_H - vh / 2, cam.ty));
  const kz = 1 - Math.exp(-dt * 3);
  cam.z += (cam.tz - cam.z) * kz; cam.cx += (cx - cam.cx) * kz; cam.cy += (cy - cam.cy) * kz;
  view.es = view.s * cam.z;
}

// ── Relleno del sobrante: mapa ampliado y difuminado en vez de franjas negras ──
let bgCanvas = null;
function drawFill() {
  if (!mapCanvas) return;
  const wx = view.cw / 2 - cam.cx * view.es, wy = view.ch / 2 - cam.cy * view.es;
  const ww = WORLD_W * view.es, wh = WORLD_H * view.es;
  if (wx <= 0.5 && wy <= 0.5 && wx + ww >= view.cw - 0.5 && wy + wh >= view.ch - 0.5) return; // ya llena todo
  if (!bgCanvas || bgCanvas._src !== mapCanvas) {
    bgCanvas = document.createElement('canvas');
    bgCanvas.width = 40; bgCanvas.height = Math.max(24, Math.round(40 * WORLD_H / WORLD_W));
    bgCanvas.getContext('2d').drawImage(mapCanvas, 0, 0, bgCanvas.width, bgCanvas.height);
    bgCanvas._src = mapCanvas;
  }
  const k = Math.max(view.cw / bgCanvas.width, view.ch / bgCanvas.height);
  const dw = bgCanvas.width * k, dh = bgCanvas.height * k;
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(bgCanvas, (view.cw - dw) / 2, (view.ch - dh) / 2, dw, dh);
  ctx.fillStyle = 'rgba(7,8,12,0.55)';
  ctx.fillRect(0, 0, view.cw, view.ch);
}

// ── Game loop ─────────────────────────────────────────────────────────────────

let lastT = performance.now();

function gameLoop(t) {
  const now = t || performance.now();
  const dt  = Math.min(0.1, Math.max(0.001, (now - lastT) / 1000));
  lastT = now;

  ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);
  ctx.fillStyle = '#07080c';
  ctx.fillRect(0, 0, view.cw, view.ch);

  let sx = 0, sy = 0;
  if (shake > 0.3) {
    sx = (Math.random() - 0.5) * shake; sy = (Math.random() - 0.5) * shake;
    shake *= Math.exp(-dt * 6);
  } else {
    shake = 0;
  }

  const all = Array.from(state.players.values());
  all.forEach(p => updateVis(p, dt, now));
  updateCamera(dt);
  const es = view.es;
  drawFill();

  ctx.save();
  ctx.translate(view.cw / 2 + sx * view.s, view.ch / 2 + sy * view.s);
  ctx.scale(es, es);
  ctx.translate(-cam.cx, -cam.cy);
  ctx.beginPath(); ctx.rect(0, 0, WORLD_W, WORLD_H); ctx.clip();

  drawWorldBackground(now);
  drawZone(now, dt);

  drawLeaderAura(now);
  all.filter(p => !p.alive).forEach(p => drawPlayer(p, now));
  all.filter(p =>  p.alive)
     .sort((a, b) => vis.get(a.userId).ry - vis.get(b.userId).ry)
     .forEach(p => drawPlayer(p, now));

  drawLabels(all.filter(p => p.alive), dt, now);
  updateAndDrawEffects(dt);
  ctx.restore();

  // Borde del mundo y cartel
  ctx.setTransform(view.dpr, 0, 0, view.dpr, 0, 0);
  ctx.strokeStyle = 'rgba(232,255,59,0.18)';
  ctx.lineWidth   = 2;
  ctx.strokeRect(view.cw / 2 - cam.cx * es, view.ch / 2 - cam.cy * es, WORLD_W * es, WORLD_H * es);
  drawCanvasHUD();

  requestAnimationFrame(gameLoop);
}
requestAnimationFrame(gameLoop);

// ── Mensajes del servidor ─────────────────────────────────────────────────────

// Mezcla los datos del servidor en el jugador existente (x,y son el "destino")
function upsertPlayer(p) {
  let ex = state.players.get(p.userId);
  if (!ex) {
    state.players.set(p.userId, p);
    ex = p;
    getVis(p);
  } else {
    Object.assign(ex, p);
  }
  if (ex.profilePictureUrl) loadAvatar(ex.userId);
  return ex;
}

function applyGlobal(msg) {
  if (msg.phase     !== undefined) state.phase     = msg.phase;
  if (msg.lobbyLeft !== undefined) state.lobbyLeft = msg.lobbyLeft;
  if (msg.waiting   !== undefined) state.waiting   = msg.waiting;
  if (msg.queue     !== undefined) state.queue     = msg.queue;
  if (msg.max       !== undefined) state.max       = msg.max;
  if (msg.zone)                    state.zone      = msg.zone;
  if (msg.world)                   applyWorld(msg.world);
}

let lastUI = 0;

// ── Alerta grande de regalos ──
const GIFT_ALERTS = {
  gift_heal:      m => [m.player,   '🌹', `envió ${m.giftName}`,                    'heal'],
  gift_attack:    m => [m.attacker, '🎁', `atacó a ${m.target} con ${m.giftName}`,  'attack'],
  gift_bomb:      m => [m.sender,   '💣', `lanzó una BOMBA (${m.giftName})`,        'bomb'],
  gift_mega_bomb: m => [m.sender,   '🌟', `lanzó una MEGA BOMBA (${m.giftName})`,   'mega'],
};
const giftQueue = []; let giftBusy = false;
function giftAlert(name, icon, text, cls) {
  giftQueue.push({ name, icon, text, cls });
  if (!giftBusy) nextGiftAlert();
}
function nextGiftAlert() {
  const a = giftQueue.shift();
  if (!a) { giftBusy = false; return; }
  giftBusy = true;
  const p  = Array.from(state.players.values()).find(x => x.username === a.name);
  const el = document.getElementById('gift-alert');
  el.className = `ga-${a.cls}`;
  el.innerHTML = (p ? `<img src="/avatar/${p.userId}" onerror="this.remove()">` : `<span class="ga-icon">${a.icon}</span>`) +
                 `<div><b>${p ? (p.nickname || p.username) : a.name}</b><br>${a.icon} ${a.text}</div>`;
  void el.offsetWidth;            // reinicia la animación
  el.classList.add('show');
  setTimeout(() => { el.classList.remove('show'); setTimeout(nextGiftAlert, 250); }, 2600);
}

// ── Ranking de sesión (alterna con el top de la ronda) ──
let sessionTop = [], lbMode = 'round';
setInterval(() => { lbMode = (lbMode === 'round' && sessionTop.length) ? 'session' : 'round'; updateLeaderboard(); }, 8000);

// ── Cuenta regresiva del lobby ──
function updateCountdown() {
  const c = document.getElementById('countdown');
  if (!c) return;
  if (state.running && state.phase === 'lobby') {
    const alive = Array.from(state.players.values()).filter(p => p.alive).length;
    c.textContent = state.waiting ? `Esperando jugadores (${alive}/2)\n💬 Comenta para entrar` : `⚔️ Empieza en ${state.lobbyLeft}s`;
    c.classList.remove('hidden');
  } else c.classList.add('hidden');
}

function handleMessage(msg) {
  if (window.LiveExtras) window.LiveExtras.handle(msg); // voz de agradecimiento + música (thanks.js)
  if (msg.type === 'game_reset' || msg.type === 'game_start') setTimeout(sendView, 50);
  if (GIFT_ALERTS[msg.type]) giftAlert(...GIFT_ALERTS[msg.type](msg));
  if (msg.type === 'session') { sessionTop = msg.top; if (lbMode === 'session') updateLeaderboard(); }
  if (msg.type === 'config')  { state.max = msg.max; updateHUD(); }
  switch (msg.type) {

    case 'game_state': {
      if (msg.build) {
        if (window.__build && window.__build !== msg.build) { location.reload(); return; }
        window.__build = msg.build;
      }
      state.running = msg.state.running;
      state.round   = msg.state.round;
      applyGlobal(msg.state);
      state.waiting = msg.state.players.filter(p => p.alive).length < 2;
      msg.state.players.forEach(upsertPlayer);
      sessionTop = msg.state.session || [];
      // Al conectarse tarde, ponemos a todos directamente en su sitio
      state.players.forEach(p => { const v = getVis(p); v.rx = p.x; v.ry = p.y; });
      zoneView.r = state.zone.r; zoneView.toR = state.zone.toR;
      updateHUD(); updateLeaderboard();
      if (state.running) hideOverlay();
      break;
    }

    case 'tick': {
      applyGlobal(msg);
      msg.players.forEach(upsertPlayer);
      const now = performance.now();
      if (now - lastUI > 400) { lastUI = now; updateHUD(); updateLeaderboard(); }
      break;
    }

    case 'game_start': {
      state.running = true; state.round = msg.round;
      hideOverlay(); setStatus('live', 'Live activo');
      showBanner(`🏟️ Ronda ${msg.round} — ¡comenta para unirte!`);
      updateHUD();
      break;
    }

    case 'battle_start': {
      state.phase = 'battle';
      hideOverlay();
      showBanner('⚔️ ¡EMPIEZA LA BATALLA!');
      addFeedItem('⚔️ ¡Empieza la batalla!', 'ev-mega');
      shake = 8;
      break;
    }

    case 'game_paused': { state.running = false; setStatus('off', 'Live pausado'); break; }

    case 'game_reset': {
      state.players.clear(); vis.clear();
      particles.length = 0; floaters.length = 0; shockwaves.length = 0;
      state.running = false; state.round = msg.round; state.phase = 'lobby'; state.waiting = true;
      zoneView.r = zoneView.toR = 470;
      updateHUD(); updateLeaderboard();
      showOverlay('⚔️', `Ronda ${msg.round}`, '¡Nueva batalla comenzando!');
      setTimeout(hideOverlay, 3000);
      break;
    }

    case 'game_over': {
      state.running = false;
      state.phase   = 'over';
      if (msg.winner) {
        showOverlay('🏆', `¡${msg.winner.nickname || msg.winner.username} ganó!`, `Kills: ${msg.winner.kills} · 💎 ${msg.winner.gifts}` + (msg.queue ? `<br/>Siguiente ronda: ${msg.queue} en cola` : ''), true);
        showBanner(`🏆 ${msg.winner.nickname || msg.winner.username} es el campeón!`);
        const w = state.players.get(msg.winner.userId);
        if (w) { const v = getVis(w); v.winAt = performance.now(); spawnParticles(v.rx, v.ry, '#e8ff3b', 30); }
      } else {
        showOverlay('💀', '¡Todos eliminados!', 'Nueva ronda en breve...', true);
      }
      updateLeaderboard();
      break;
    }

    case 'player_joined': {
      const p = upsertPlayer(msg.player);
      const v = getVis(p); v.rx = p.x; v.ry = p.y;
      spawnParticles(p.x, p.y, '#e8ff3b', 6);
      addFeedItem(`<span class="actor">${p.nickname || p.username}</span> entró`, '');
      updateHUD(); updateLeaderboard();
      break;
    }

    case 'player_eliminated': {
      const p = byIdOrName(msg.playerId, msg.player);
      if (p) {
        p.alive = false;
        const v = getVis(p); v.deadAt = performance.now();
        spawnParticles(v.rx, v.ry, '#ff3b5c', 14);
      }
      let extra = '';
      if (msg.reason === 'zone') extra = ' en la zona roja';
      else if (msg.killedBy)     extra = ` por <span class="actor">${msg.killedBy}</span>`;
      addFeedItem(`💀 <span class="actor">${msg.player}</span> eliminado${extra}`, 'ev-elim');
      updateHUD(); updateLeaderboard();
      break;
    }

    case 'combat': {
      const att = byIdOrName(msg.attackerId, msg.attacker);
      const tgt = byIdOrName(msg.targetId,   msg.target);
      startAttack(att, tgt);
      startHit(tgt, att);
      if (tgt) {
        const tv = getVis(tgt);
        spawnSpark(tv.rx, tv.ry, msg.crit ? '#e8ff3b' : '#ffb0b0');
        if (msg.crit) { spawnFloater(tv.rx, tv.ry - 26, `¡${msg.damage}!`, '#e8ff3b', 17); shake = Math.max(shake, 3); }
        else          spawnFloater(tv.rx, tv.ry - 26, `-${msg.damage}`, '#ff5c7a');
      }
      break;
    }

    case 'comment_heal': {
      const p = findPlayer(msg.player);
      if (p) { const v = getVis(p); spawnFloater(v.rx, v.ry - 26, `+${msg.amount}HP`, '#3bffb0'); }
      addFeedItem(`💬 <span class="actor">${msg.player}</span> +${msg.amount}HP`, 'ev-heal');
      break;
    }

    case 'comment_attack': {
      const att = findPlayer(msg.attacker), tgt = findPlayer(msg.target);
      startAttack(att, tgt); startHit(tgt, att);
      if (tgt) { const v = getVis(tgt); spawnParticles(v.rx, v.ry, '#ff3b5c', 6); spawnFloater(v.rx, v.ry - 26, `-${msg.damage}`, '#ff3b5c'); }
      addFeedItem(`💬 <span class="actor">${msg.attacker}</span> atacó a ${msg.target} (${msg.damage})`, 'ev-elim');
      break;
    }

    case 'gift_heal': {
      const p = findPlayer(msg.player);
      if (p) { const v = getVis(p); spawnParticles(v.rx, v.ry, '#3bffb0', 10); spawnFloater(v.rx, v.ry - 26, `+${msg.amount}HP`, '#3bffb0', 15); }
      addFeedItem(`🎁 <span class="actor">${msg.player}</span> ${msg.giftName} +${msg.amount}HP`, 'ev-gift ev-heal');
      break;
    }

    case 'gift_attack': {
      const att = findPlayer(msg.attacker), tgt = findPlayer(msg.target);
      startAttack(att, tgt); startHit(tgt, att);
      if (tgt) { const v = getVis(tgt); spawnParticles(v.rx, v.ry, '#ff8c3b', 12); spawnFloater(v.rx, v.ry - 26, `-${msg.damage}`, '#ff8c3b', 17); shake = Math.max(shake, 5); }
      addFeedItem(`🎁 <span class="actor">${msg.attacker}</span> atacó a ${msg.target} con ${msg.giftName}`, 'ev-gift');
      break;
    }

    case 'gift_bomb':
    case 'gift_mega_bomb': {
      const mega = msg.type === 'gift_mega_bomb';
      const s    = findPlayer(msg.sender);
      const sv   = s ? getVis(s) : { rx: WORLD_W / 2, ry: WORLD_H / 2 };
      showBanner(`${mega ? '🌟 MEGA BOMBA' : '💣 BOMBA'} de ${msg.sender} con ${msg.giftName}!`);
      spawnShockwave(sv.rx, sv.ry, mega ? '#e8ff3b' : '#ff8c3b');
      shake = mega ? 16 : 10;
      state.players.forEach(p => {
        if (!p.alive || p.username === msg.sender) return;
        startHit(p, s);
        const v = getVis(p);
        spawnParticles(v.rx, v.ry, mega ? '#e8ff3b' : '#ff8c3b', mega ? 10 : 6);
        spawnFloater(v.rx, v.ry - 26, `-${msg.damage}`, mega ? '#e8ff3b' : '#ff8c3b', 15);
      });
      addFeedItem(`${mega ? '🌟' : '💣'} <span class="actor">${msg.sender}</span> ${mega ? 'MEGA BOMBA' : 'BOMBA'} — ${msg.damage} daño`, mega ? 'ev-mega' : 'ev-bomb');
      break;
    }

    case 'zone_warning': {
      showBanner(`⚠️ La zona se cierra en ${msg.in}s`);
      addFeedItem(`⚠️ Zona ${msg.phase}: se cierra en ${msg.in}s`, '');
      break;
    }

    case 'zone_start': {
      showBanner(`🔴 ¡LA ZONA SE CIERRA! −${msg.dps} HP/s fuera`);
      addFeedItem(`🔴 Zona ${msg.phase} cerrándose (−${msg.dps} HP/s fuera)`, 'ev-bomb');
      shake = Math.max(shake, 6);
      break;
    }

    case 'like_event':   addFeedItem(`❤️ <span class="actor">${msg.player}</span> +${msg.heal}HP por ${msg.trigger} likes`, 'ev-heal'); break;
    case 'share_bonus':  addFeedItem(`🔁 <span class="actor">${msg.player}</span> compartió +${msg.heal}HP`, 'ev-heal'); break;
  }
}

// ── UI helpers ────────────────────────────────────────────────────────────────

function setStatus(mode, text) {
  document.getElementById('status-dot').className    = mode === 'live' ? 'live' : mode === 'ready' ? 'ready' : '';
  document.getElementById('status-text').textContent = text;
}

function updateHUD() {
  const alive = Array.from(state.players.values()).filter(p => p.alive).length;
  document.getElementById('alive-count').textContent = alive;
  document.getElementById('round-num').textContent   = state.round;
  const qc = document.getElementById('queue-chip');
  if (qc) qc.textContent = state.queue > 0 ? `👥 ${state.queue} en cola` : '';
  const mx = document.getElementById('ht-max'); if (mx) mx.textContent = state.max;
  updateCountdown();
}

function updateLeaderboard() {
  const list = document.getElementById('lb-list');
  document.getElementById('lb-title').textContent = lbMode === 'session' ? '🏆 Sesión' : 'Top · Ronda';
  if (lbMode === 'session') {
    list.innerHTML = sessionTop.map((e, i) => `<li>
      <span class="lb-rank">${i + 1}</span><span class="lb-name">${e.name}</span>
      <span class="lb-hp">🏆${e.wins} · 💎${e.diamonds}</span></li>`).join('');
    return;
  }
  const players = Array.from(state.players.values())
    .sort((a, b) => (b.alive - a.alive) || ((b.kills || 0) - (a.kills || 0)) || (b.hp - a.hp))
    .slice(0, 10);
  list.innerHTML = players.map((p, i) => {
    const tc = TIER_CFG[p.tier || 'villager'];
    return `<li class="${p.alive ? '' : 'dead'}">
      <span class="lb-rank">${i + 1}</span>
      <span class="lb-name" style="color:${p.alive ? tc.body : '#555'}">${p.nickname || p.username}</span>
      <span class="lb-hp">${p.alive ? `⚔${p.kills || 0} · ${p.hp}HP` : '💀'}</span>
    </li>`;
  }).join('');
}

function addFeedItem(html, cls) {
  const list = document.getElementById('feed-list');
  const li   = document.createElement('li');
  li.className = cls || ''; li.innerHTML = html;
  list.prepend(li);
  while (list.children.length > 80) list.removeChild(list.lastChild);
}

function showOverlay(icon, title, sub, light = false) {
  const ov = document.getElementById('overlay');
  document.getElementById('overlay-icon').textContent  = icon;
  document.getElementById('overlay-title').textContent = title;
  document.getElementById('overlay-sub').innerHTML     = sub;
  ov.classList.toggle('light', light);
  ov.classList.remove('hidden');
}

function hideOverlay() { document.getElementById('overlay').classList.add('hidden'); }

let bannerTimer = null;
function showBanner(text) {
  const b = document.getElementById('event-banner');
  b.textContent = text; b.classList.remove('hidden');
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => b.classList.add('hidden'), 3500);
}

// Tecla H: mostrar/ocultar la guía "Cómo jugar"
document.addEventListener('keydown', (e) => {
  if (e.key === 'h' || e.key === 'H') {
    const h = document.getElementById('howto');
    if (h) h.classList.toggle('hidden');
  }
});
