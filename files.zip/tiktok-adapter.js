// Convierte los mensajes protobuf (esquema v3) de tiktok-live-connector v2
// al formato plano que usa game.js (el mismo que daba la v1).

function userOf(d) {
  const u = (d && d.user) || {};
  const pics = (u.avatarLarge || u.avatarMedium || u.avatarThumb || {}).urlList || [];
  return {
    userId:   String(u.idStr || u.id || ''),
    username: u.displayId || u.uniqueId || '',
    nickname: u.nickname || '',
    profilePictureUrl: pics.find(x => !/shrink/.test(x)) || pics[0] || null,
  };
}

const chatOf = (d) => ({ ...userOf(d), comment: d.comment || '' });

function giftOf(d) {
  const g = d.gift || {};
  return {
    ...userOf(d),
    giftId:       d.giftId || g.id,
    giftName:     g.name || '',
    giftType:     g.type,                 // 1 = regalo de racha (streak)
    diamondCount: Number(g.diamondCount) || 0,
    repeatCount:  Number(d.repeatCount) || 1,
    repeatEnd:    !!d.repeatEnd,
  };
}

const likeOf = (d) => ({
  ...userOf(d),
  likeCount:      Number(d.count) || 0,
  totalLikeCount: Number(d.total) || 0,
});

module.exports = { userOf, chatOf, giftOf, likeOf };
