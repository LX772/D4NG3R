// ═══════════════════════════════════════════════════════════════════════════
//  thanks.js — Voz de agradecimiento (follow / regalos) + música de fondo
//  Se conecta con una sola línea en game-render.js: window.LiveExtras.handle(msg)
// ═══════════════════════════════════════════════════════════════════════════
(() => {
  // ── Ajustes (cámbialos aquí) ──────────────────────────────────────────────
  const CFG = {
    thankFollows: true,
    thankGifts: true,
    minGiftDiamonds: 1,      // solo agradece regalos de al menos estos diamantes
    voiceRate: 1.05,         // velocidad de la voz
    voicePitch: 1.05,
    voiceVolume: 1,
    maxQueue: 4,             // si llegan muchos a la vez, descarta los más viejos
    musicVolume: 0.22,       // volumen normal de la música (0 a 1)
    duckVolume: 0.06,        // volumen de la música mientras habla la voz
    maxNameLength: 22,
  };

  const GIFT_ES = { Rose: 'rosa', 'Heart Me': 'corazón', 'GG': 'GG', Finger: 'corazón con los dedos',
                    'TikTok': 'TikTok', Lion: 'león', Universe: 'universo', Galaxy: 'galaxia' };

  // ── Estado ────────────────────────────────────────────────────────────────
  let audioOn = false;
  let musicOn = true;
  let musicVol = CFG.musicVolume;
  let speaking = false;
  let voice = null;
  const queue = [];
  const lastThanked = new Map();

  // ── Voz (Web Speech API del navegador) ────────────────────────────────────
  function pickVoice() {
    const vs = (window.speechSynthesis && speechSynthesis.getVoices()) || [];
    const es = vs.filter(v => /^es/i.test(v.lang));
    const score = (v) =>
      (/es-(MX|US|419)/i.test(v.lang) ? 3 : /es-ES/i.test(v.lang) ? 2 : 1) +
      (/natural|online|google/i.test(v.name) ? 2 : 0);
    es.sort((a, b) => score(b) - score(a));
    voice = es[0] || null;
  }
  if (window.speechSynthesis) {
    pickVoice();
    speechSynthesis.onvoiceschanged = pickVoice;
  }

  function cleanName(n) {
    // Quita emojis y símbolos raros para que la voz no los deletree
    let s = String(n || '').replace(/[^\p{L}\p{N} ._-]/gu, ' ').replace(/[._-]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (s.length > CFG.maxNameLength) s = s.slice(0, CFG.maxNameLength);
    return s || 'amigo';
  }
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  function buildText(m) {
    const n = cleanName(m.name);
    if (m.kind === 'follow') {
      return pick([
        `¡Gracias por seguirnos, ${n}!`,
        `¡Bienvenido a la familia, ${n}! Gracias por el follow.`,
        `${n}, gracias por seguirme. ¡Eres grande!`,
      ]);
    }
    const raw = m.gift || 'regalo';
    const g = GIFT_ES[raw] || raw;
    const plural = GIFT_ES[raw] ? (/[aeiou]$/i.test(g) ? g + 's' : g + 'es') : g;
    const what = (m.count || 1) > 1 ? `${m.count} ${plural}` : `el ${g}`;
    if ((m.diamonds || 0) >= 500) {
      return pick([`¡Wow! ¡Gracias ${n} por ${what}! ¡Eres una leyenda!`, `¡Increíble, ${n}! Gracias por ${what}.`]);
    }
    return pick([`¡Gracias ${n} por ${what}!`, `${n}, mil gracias por ${what}.`, `¡Qué crack, ${n}! Gracias por ${what}.`]);
  }

  function enqueue(text, key) {
    if (!audioOn || !window.speechSynthesis) return;
    const now = Date.now();
    if (key && now - (lastThanked.get(key) || 0) < 4000) return;   // evita repetir al mismo usuario
    if (key) lastThanked.set(key, now);
    queue.push(text);
    while (queue.length > CFG.maxQueue) queue.shift();
    next();
  }

  function next() {
    if (speaking || !queue.length) return;
    const u = new SpeechSynthesisUtterance(queue.shift());
    if (voice) { u.voice = voice; u.lang = voice.lang; } else u.lang = 'es-MX';
    u.rate = CFG.voiceRate; u.pitch = CFG.voicePitch; u.volume = CFG.voiceVolume;
    speaking = true;
    music.duck(true);
    const done = () => { speaking = false; if (!queue.length) music.duck(false); next(); };
    u.onend = done; u.onerror = done;
    speechSynthesis.speak(u);
  }

  // ── Música de fondo ───────────────────────────────────────────────────────
  // 1) Si hay archivos en public/music/ (mp3, ogg, wav) los reproduce en orden aleatorio.
  // 2) Si no hay, genera un ambiente musical propio con Web Audio (original → sin copyright).
  const music = (() => {
    let ctx = null, master = null, timer = null, tracks = [], el = null, mode = 'none', ducked = false;

    const level = () => (ducked ? CFG.duckVolume : musicVol);
    const apply = () => {
      if (el) el.volume = Math.min(1, level());
      if (master && ctx) master.gain.setTargetAtTime(level(), ctx.currentTime, 0.25);
    };

    const midi = (n) => 440 * Math.pow(2, (n - 69) / 12);
    const CHORDS = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]];   // Am – F – C – G
    const ARP = [0, 2, 4, 2, 5, 4, 2, 1];                                       // notas de la escala
    const SCALE = [69, 72, 74, 76, 79, 81];                                     // pentatónica menor de La
    let step = 0;

    function playBar() {
      const t0 = ctx.currentTime + 0.05;
      const chord = CHORDS[step % CHORDS.length];
      chord.forEach((n, i) => {
        [-6, 6].forEach((det) => {
          const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
          o.type = 'triangle'; o.frequency.value = midi(n); o.detune.value = det;
          f.type = 'lowpass'; f.frequency.value = 1100;
          g.gain.setValueAtTime(0.0001, t0);
          g.gain.linearRampToValueAtTime(0.10, t0 + 1.6);
          g.gain.linearRampToValueAtTime(0.0001, t0 + 6.4);
          o.connect(f); f.connect(g); g.connect(master);
          o.start(t0); o.stop(t0 + 6.6);
        });
      });
      ARP.forEach((idx, i) => {
        const t = t0 + i * 0.75, o = ctx.createOscillator(), g = ctx.createGain();
        o.type = 'sine'; o.frequency.value = midi(SCALE[idx % SCALE.length] + (step % 4 === 2 ? -5 : 0));
        g.gain.setValueAtTime(0.0001, t);
        g.gain.exponentialRampToValueAtTime(0.09, t + 0.03);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
        o.connect(g); g.connect(master);
        o.start(t); o.stop(t + 1);
      });
      step++;
    }

    function startGenerative() {
      if (mode === 'gen') return;
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume();
      master = ctx.createGain(); master.gain.value = level(); master.connect(ctx.destination);
      mode = 'gen'; playBar(); timer = setInterval(playBar, 6000);
    }

    function startFiles() {
      mode = 'files';
      el = new Audio(); el.preload = 'auto';
      const playRandom = () => { el.src = tracks[Math.floor(Math.random() * tracks.length)]; el.volume = level(); el.play().catch(() => {}); };
      el.onended = playRandom; el.onerror = () => setTimeout(playRandom, 1500);
      playRandom();
    }

    return {
      async start() {
        if (mode !== 'none') { apply(); if (ctx && ctx.state === 'suspended') ctx.resume(); if (el) el.play().catch(() => {}); return; }
        try { tracks = await (await fetch('/music-list')).json(); } catch (_) { tracks = []; }
        tracks.length ? startFiles() : startGenerative();
      },
      stop() {
        if (timer) { clearInterval(timer); timer = null; }
        if (master) { try { master.disconnect(); } catch (_) {} master = null; }
        if (el) { el.pause(); el = null; }
        mode = 'none'; step = 0;
      },
      duck(on) { ducked = on; apply(); },
      apply,
    };
  })();

  // ── Panel de control (pequeño, se atenúa solo) ────────────────────────────
  function buildUI() {
    const box = document.createElement('div');
    box.id = 'live-extras';
    box.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:9999;font:600 13px Inter,system-ui,sans-serif;' +
      'background:rgba(10,12,20,.82);color:#fff;border:1px solid #ffffff33;border-radius:12px;padding:8px 10px;' +
      'display:flex;gap:8px;align-items:center;transition:opacity .4s;';
    box.innerHTML =
      '<button id="le-on" style="background:#3bffb0;color:#000;border:0;border-radius:8px;padding:6px 10px;font-weight:700;cursor:pointer">🔊 Activar audio</button>' +
      '<span id="le-ctl" style="display:none;gap:8px;align-items:center">' +
      '<button id="le-music" title="Música" style="background:#222;color:#fff;border:1px solid #ffffff44;border-radius:8px;padding:5px 8px;cursor:pointer">🎵 ON</button>' +
      '<input id="le-vol" type="range" min="0" max="100" value="' + Math.round(musicVol * 100) + '" style="width:80px">' +
      '<button id="le-test" title="Probar voz" style="background:#222;color:#fff;border:1px solid #ffffff44;border-radius:8px;padding:5px 8px;cursor:pointer">🗣️</button>' +
      '</span>';
    document.body.appendChild(box);

    const $ = (id) => box.querySelector('#' + id);
    let fade;
    const dim = () => { clearTimeout(fade); box.style.opacity = '1'; fade = setTimeout(() => { if (audioOn) box.style.opacity = '.18'; }, 4000); };
    box.addEventListener('pointerdown', dim); box.addEventListener('mouseenter', dim);

    $('le-on').onclick = () => {
      audioOn = true;
      $('le-on').style.display = 'none'; $('le-ctl').style.display = 'flex';
      if (window.speechSynthesis) { speechSynthesis.cancel(); pickVoice(); }
      if (musicOn) music.start();
      enqueue('Audio activado. ¡Bienvenidos al live!');
      dim();
    };
    $('le-music').onclick = () => {
      musicOn = !musicOn;
      $('le-music').textContent = musicOn ? '🎵 ON' : '🎵 OFF';
      musicOn ? music.start() : music.stop();
    };
    $('le-vol').oninput = (e) => { musicVol = Number(e.target.value) / 100; music.apply(); };
    $('le-test').onclick = () => enqueue(buildText({ kind: 'follow', name: 'Luis' }));
    if (new URLSearchParams(location.search).get('ui') === '0') box.style.display = 'none';
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', buildUI); else buildUI();

  // ── API que usa game-render.js ────────────────────────────────────────────
  window.LiveExtras = {
    handle(msg) {
      if (!msg || msg.type !== 'thanks') return;
      if (msg.kind === 'follow' && CFG.thankFollows) enqueue(buildText(msg), 'f:' + msg.name);
      if (msg.kind === 'gift' && CFG.thankGifts && (msg.diamonds || 0) >= CFG.minGiftDiamonds) enqueue(buildText(msg), 'g:' + msg.name);
    },
  };
})();
