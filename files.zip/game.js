// ── Constantes ───────────────────────────────────────────────────────────────

const TICK_RATE = 100; // ms entre ticks (10 por segundo, el cliente interpola)

// Mundo lógico: el frontend lo escala a cualquier tamaño de pantalla
const WORLD = { W: 500, H: 800, MARGIN: 26, LOBBY_SECONDS: 20, MAX_PLAYERS: 20, MAX_QUEUE: 300 };

// Ajustes por variables de entorno: MAX_PLAYERS=12 LOBBY=10 node server.js
const WORLD_DEFAULT = { W: WORLD.W, H: WORLD.H };
if (+process.env.MAX_PLAYERS) WORLD.MAX_PLAYERS = Math.max(2, Math.min(30, +process.env.MAX_PLAYERS));
if (+process.env.LOBBY)       WORLD.LOBBY_SECONDS = Math.max(5, Math.min(120, +process.env.LOBBY));

const HP = {
  BASE: 100,
  MAX: 1000,
  COMMENT_GAIN: 10,
  HIT_COOLDOWN_MS: 6000,     // anti-spam: una misma víctima no puede recibir ataques por comentario más seguido
  COMMENT_COOLDOWN_MS: 8000, // un comentario cada 8s da HP
  LIKE_BATCH: 50,            // cada 50 likes de UN jugador = curación para ese jugador
  LIKE_HEAL: 5,              // HP que recibe por cada lote de likes
  SHARE_BONUS: 30,
};

// Valor en diamantes → acción
const GIFT_TIERS = {
  SMALL:  { max: 10,   action: 'heal',    value: 50  }, // Rosa, etc.
  MEDIUM: { max: 100,  action: 'attack',  value: 150 }, // Regalo mediano
  LARGE:  { max: 999,  action: 'bomb',    value: 300 }, // Regalo grande
  MEGA:   { max: Infinity, action: 'mega_bomb', value: 600 }, // Universe, etc.
};

// Combate automático: cada personaje camina hacia el enemigo más cercano y lo golpea
const COMBAT = {
  STOP_DIST:    26,   // se detienen a esta distancia (px del mundo)
  ATTACK_RANGE: 34,   // alcance del golpe
  CRIT_CHANCE:  0.12,
  SPEED:    { villager: 36,  soldier: 44,  knight: 40,  king: 52  }, // px/segundo
  DAMAGE:   { villager: 4,   soldier: 5,   knight: 6,   king: 8   }, // daño base por golpe
  COOLDOWN: { villager: 1.3, soldier: 1.1, knight: 1.0, king: 0.85 }, // segundos entre golpes
};

// Zona roja que se cierra. Quien queda fuera pierde HP cada segundo.
const ZONE = {
  START_R:        470,  // cubre todo el mapa al inicio
  MIN_R:          55,
  FACTOR:         0.62, // cada fase el radio se multiplica por esto
  FIRST_DELAY:    25,   // segundos antes del primer cierre
  HOLD_SECONDS:   20,   // pausa entre cierres
  SHRINK_SECONDS: 18,   // duración de cada cierre
  WARN_SECONDS:   8,    // aviso antes de cada cierre
  BASE_DPS:       4,    // daño por segundo fuera de la zona (fase 0)
  DPS_PER_PHASE:  3,    // +daño por fase
};

// ── Helpers ──────────────────────────────────────────────────────────────────

function clamp(val, min, max) {
  return Math.max(min, Math.min(max, val));
}

function randomFrom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function giftTier(diamondCount) {
  if (diamondCount <= GIFT_TIERS.SMALL.max)  return { tier: 'SMALL',  ...GIFT_TIERS.SMALL  };
  if (diamondCount <= GIFT_TIERS.MEDIUM.max) return { tier: 'MEDIUM', ...GIFT_TIERS.MEDIUM };
  if (diamondCount <= GIFT_TIERS.LARGE.max)  return { tier: 'LARGE',  ...GIFT_TIERS.LARGE  };
  return { tier: 'MEGA', ...GIFT_TIERS.MEGA };
}

// ── Player ───────────────────────────────────────────────────────────────────

// Tier según diamantes donados acumulados
function playerTier(diamonds) {
  if (diamonds >= 101) return 'king';
  if (diamonds >= 11)  return 'knight';
  if (diamonds >= 1)   return 'soldier';
  return 'villager';
}

class Player {
  constructor({ userId, username, nickname, profilePictureUrl }) {
    this.userId   = userId;
    this.username = username;
    this.nickname = nickname || username;
    this.profilePictureUrl = profilePictureUrl || null;

    this.hp       = HP.BASE;
    this.maxHp    = HP.BASE;
    this.armor    = 0;       // reduce daño recibido (%)
    this.alive    = true;
    this.kills    = 0;
    this.gifts    = 0;       // diamantes totales donados
    this.tier     = 'villager';
    this.lastCommentAt = 0;
    this.lastHitAt = 0;      // último ataque por comentario recibido
    this.likeAcc  = 0;       // likes acumulados de este jugador

    // Posición en el canvas (el frontend la usa)
    this.x = 60 + Math.random() * (WORLD.W - 120);
    this.y = 60 + Math.random() * (WORLD.H - 120);

    // Estado de combate (lo maneja el motor)
    this.tid          = null;  // userId del enemigo al que apunta
    this.flee         = false; // true si corre hacia la zona segura
    this.nextAttackAt = 0;
    this.zoneAcc      = 0;     // daño de zona acumulado (fracciones)

    // Efecto visual temporal
    this.effect   = null;    // 'healed' | 'attacked' | 'bombed' | 'shielded'
    this.effectAt = 0;
  }

  serialize() {
    return {
      userId:   this.userId,
      username: this.username,
      nickname: this.nickname,
      profilePictureUrl: this.profilePictureUrl,
      tier:     this.tier,
      hp:       this.hp,
      maxHp:    this.maxHp,
      armor:    this.armor,
      alive:    this.alive,
      kills:    this.kills,
      gifts:    this.gifts,
      x:        this.x,
      y:        this.y,
      effect:   this.effect,
      tid:      this.tid,
      flee:     this.flee,
    };
  }

  takeDamage(amount) {
    if (!this.alive) return 0;
    const reduced = Math.floor(amount * (1 - this.armor / 100));
    this.hp = clamp(this.hp - reduced, 0, this.maxHp);
    if (this.hp === 0) this.alive = false;
    return reduced;
  }

  // Daño de zona: ignora armadura
  takeTrueDamage(amount) {
    if (!this.alive) return 0;
    this.hp = clamp(this.hp - amount, 0, this.maxHp);
    if (this.hp === 0) this.alive = false;
    return amount;
  }

  heal(amount) {
    if (!this.alive) return;
    this.hp = clamp(this.hp + amount, 0, this.maxHp);
    this.effect = 'healed';
    this.effectAt = Date.now();
  }

  addArmor(amount) {
    this.armor = clamp(this.armor + amount, 0, 80); // max 80% reducción
    this.effect = 'shielded';
    this.effectAt = Date.now();
  }

  upgradeMaxHp(amount) {
    this.maxHp = clamp(this.maxHp + amount, HP.BASE, HP.MAX);
    this.hp    = clamp(this.hp    + amount, 0,       this.maxHp);
  }
}

// ── GameEngine ───────────────────────────────────────────────────────────────

class GameEngine {
  constructor() {
    this.players     = new Map(); // userId → Player (máx. 20 por ronda)
    this.queue       = new Map(); // userId → { data, gifts } esperando la siguiente ronda
    this.alive       = new Set(); // userIds vivos
    this.running     = false;
    this.phase       = 'lobby';   // 'lobby' → 'battle' → 'over'
    this.offline     = false;     // modo demo con bots
    this.time        = 0;         // segundos de juego (no avanza en pausa)
    this.lobbyLeft   = WORLD.LOBBY_SECONDS;
    this.zone        = this._newZone();
    this.tickTimer   = null;
    this.demoTimer   = null;
    this.resetTimer  = null;
    this.likeBucket  = 0;
    this.round       = 1;
    this.winner      = null;
    this.events      = []; // log de eventos recientes
    this.session     = new Map(); // ranking de todo el live: userId → { name, wins, diamonds }

    this.onBroadcast = null; // inyectado desde server.js
  }

  // ── Estado público ─────────────────────────────────────────────────────────

  getState() {
    return {
      running:   this.running,
      phase:     this.phase,
      lobbyLeft: Math.ceil(Math.max(0, this.lobbyLeft)),
      queue:     this.queue.size,
      max:       WORLD.MAX_PLAYERS,
      round:     this.round,
      winner:    this.winner,
      world:     { W: WORLD.W, H: WORLD.H },
      zone:      this._serializeZone(),
      players:   Array.from(this.players.values()).map(p => p.serialize()),
      events:    this.events.slice(-20),
      session:   this.sessionTop(),
    };
  }

  // ── Ranking de sesión ──────────────────────────────────────────────────────

  _sess(userId, name) {
    if (!this.session.has(userId)) this.session.set(userId, { name: name || String(userId), wins: 0, diamonds: 0 });
    return this.session.get(userId);
  }

  sessionTop() {
    return Array.from(this.session.values())
      .filter(e => e.wins || e.diamonds)
      .sort((a, b) => (b.wins - a.wins) || (b.diamonds - a.diamonds))
      .slice(0, 10);
  }

  // ── Configuración en vivo (panel /admin) ───────────────────────────────────

  setConfig({ max, lobby }) {
    if (max   !== undefined) WORLD.MAX_PLAYERS    = clamp(Math.round(max),   2, 30);
    if (lobby !== undefined) WORLD.LOBBY_SECONDS  = clamp(Math.round(lobby), 5, 120);
    if (this.lobbyLeft > WORLD.LOBBY_SECONDS) this.lobbyLeft = WORLD.LOBBY_SECONDS;
    this.emit('config', { max: WORLD.MAX_PLAYERS, lobby: WORLD.LOBBY_SECONDS });
  }

  // ── Broadcast ──────────────────────────────────────────────────────────────

  emit(type, payload = {}) {
    const event = { type, ...payload, ts: Date.now() };
    if (type !== 'tick' && type !== 'combat') {
      this.events.push(event);
      if (this.events.length > 100) this.events.shift();
    }
    if (this.onBroadcast) this.onBroadcast(event);
  }

  // ── Ciclo de vida ──────────────────────────────────────────────────────────

  start() {
    if (this.running) return;
    this.running = true;
    this.winner  = null;
    console.log('[Game] Iniciado');
    this.emit('game_start', { round: this.round, phase: this.phase });
    this._startTimers();
  }

  startOffline() {
    console.log('[Game] Modo offline (con bots de prueba)');
    this.offline = true;
    this.start();
    this._spawnBots();
  }

  pause() {
    this.running = false;
    this._clearTimers();
    this.emit('game_paused');
  }

  reset() {
    this._clearTimers();
    clearTimeout(this.resetTimer);
    this.players.clear();
    this.alive.clear();
    this.running    = false;
    this.winner     = null;
    this.likeBucket = 0;
    this.phase      = 'lobby';
    this.lobbyLeft  = WORLD.LOBBY_SECONDS;
    this.zone       = this._newZone();
    this.time       = 0;
    this.round++;
    this.emit('game_reset', { round: this.round });

    // Arranca sola la siguiente ronda (lobby → batalla)
    this.start();
    if (this.offline) {
      this.queue.clear();
      this._spawnBots();
    } else {
      this._fillFromQueue(); // los que esperaban entran primero
    }
  }

  _startTimers() {
    this._clearTimers();
    this.tickTimer = setInterval(() => this._tick(), TICK_RATE);
    if (this.offline) this.demoTimer = setInterval(() => this._demoEvent(), 6000);
  }

  _clearTimers() {
    clearInterval(this.tickTimer);
    clearInterval(this.demoTimer);
    this.tickTimer = null;
    this.demoTimer = null;
  }

  // ── Tick principal ─────────────────────────────────────────────────────────

  _tick() {
    const dt  = TICK_RATE / 1000;
    const now = Date.now();
    this.time += dt;

    // Limpiar efectos visuales expirados (duran 2s)
    this.players.forEach(p => {
      if (p.effect && now - p.effectAt > 2000) p.effect = null;
    });

    if (this.phase === 'lobby') {
      this._tickLobby(dt);
    } else if (this.phase === 'battle') {
      this._updateZone(dt);
      this._simulate(dt);
    }

    this.emit('tick', {
      phase:     this.phase,
      lobbyLeft: Math.ceil(Math.max(0, this.lobbyLeft)),
      waiting:   this._alivePlayers().length < 2,
      queue:     this.queue.size,
      max:       WORLD.MAX_PLAYERS,
      world:     { W: WORLD.W, H: WORLD.H },
      zone:      this._serializeZone(),
      players:   Array.from(this.players.values()).map(p => p.serialize()),
    });
  }

  // ── Lobby ──────────────────────────────────────────────────────────────────

  _tickLobby(dt) {
    if (this._alivePlayers().length < 2) {
      this.lobbyLeft = WORLD.LOBBY_SECONDS; // espera a tener al menos 2
      return;
    }
    // Si ya hay 20, no hace falta esperar tanto
    if (this.players.size >= WORLD.MAX_PLAYERS && this.lobbyLeft > 3) this.lobbyLeft = 3;
    this.lobbyLeft -= dt;
    if (this.lobbyLeft <= 0) this._startBattle();
  }

  _startBattle() {
    this.phase = 'battle';
    this.zone  = this._newZone();
    this._alivePlayers().forEach(p => {
      p.nextAttackAt = this.time + Math.random() * 0.8;
    });
    this.emit('battle_start', { players: this._alivePlayers().length });
  }

  // ── Tamaño del mundo según la pantalla ─────────────────────────────────────
  // El cliente manda el aspecto y el área deseada; solo se aplica en el lobby
  // (nunca en batalla ni en la pantalla del ganador, para que la cámara no salte). El mundo se adapta para llenar la pantalla.
  setView(aspect, area) {
    if (this.phase !== 'lobby') return false;
    aspect = clamp(+aspect || 0, 0.5, 2.4);
    area   = clamp(+area || 400000, 200000, 450000);
    if (!aspect) return false;
    const W = Math.round(Math.sqrt(area * aspect));
    const H = Math.round(area / W);
    if (Math.abs(W - WORLD.W) < 6 && Math.abs(H - WORLD.H) < 6) return false;
    const fx = W / WORLD.W, fy = H / WORLD.H;
    WORLD.W = W; WORLD.H = H;
    this.players.forEach(p => { p.x *= fx; p.y *= fy; });
    this.zone = this._newZone();
    return true;
  }

  // ── Zona ───────────────────────────────────────────────────────────────────

  _newZone() {
    const R0 = Math.round(Math.hypot(WORLD.W, WORLD.H) / 2 + 8);
    return {
      x: WORLD.W / 2, y: WORLD.H / 2,
      r: R0, fromR: R0, toR: R0,
      status: 'waiting', // 'waiting' | 'shrinking' | 'final'
      timer: ZONE.FIRST_DELAY, shrinkT: 0, phase: 0, warned: false,
    };
  }

  _zoneDps() {
    return ZONE.BASE_DPS + this.zone.phase * ZONE.DPS_PER_PHASE;
  }

  _serializeZone() {
    const z = this.zone;
    let toR = z.r, timeLeft = 0;
    if (z.status === 'waiting') {
      toR = Math.max(ZONE.MIN_R, z.r * ZONE.FACTOR);
      timeLeft = Math.ceil(Math.max(0, z.timer));
    } else if (z.status === 'shrinking') {
      toR = z.toR;
      timeLeft = Math.ceil(Math.max(0, ZONE.SHRINK_SECONDS - z.shrinkT));
    }
    return {
      x: z.x, y: z.y,
      r:   Math.round(z.r * 10) / 10,
      toR: Math.round(toR * 10) / 10,
      status: z.status, timeLeft, phase: z.phase,
      // Daño por segundo que aplicará la próxima zona / la actual
      dps: z.status === 'waiting' ? ZONE.BASE_DPS + (z.phase + 1) * ZONE.DPS_PER_PHASE : this._zoneDps(),
    };
  }

  _updateZone(dt) {
    const z = this.zone;

    if (z.status === 'waiting') {
      z.timer -= dt;
      if (!z.warned && z.timer <= ZONE.WARN_SECONDS && z.timer > 0) {
        z.warned = true;
        this.emit('zone_warning', { in: Math.ceil(z.timer), phase: z.phase + 1 });
      }
      if (z.timer <= 0) {
        z.status  = 'shrinking';
        z.fromR   = z.r;
        z.toR     = Math.max(ZONE.MIN_R, z.r * ZONE.FACTOR);
        z.shrinkT = 0;
        z.phase++;
        this.emit('zone_start', { phase: z.phase, dps: this._zoneDps() });
      }
    } else if (z.status === 'shrinking') {
      z.shrinkT += dt;
      const t = Math.min(1, z.shrinkT / ZONE.SHRINK_SECONDS);
      z.r = z.fromR + (z.toR - z.fromR) * t;
      if (t >= 1) {
        if (z.toR <= ZONE.MIN_R + 0.01) {
          z.status = 'final';
        } else {
          z.status = 'waiting';
          z.timer  = ZONE.HOLD_SECONDS;
          z.warned = false;
        }
      }
    }
  }

  // ── Simulación: movimiento + combate + zona ────────────────────────────────

  _simulate(dt) {
    const z = this.zone;

    // 1) Daño de la zona a quien está fuera
    if (z.phase > 0) {
      const dps = this._zoneDps();
      this._alivePlayers().forEach(p => {
        const outside = Math.hypot(p.x - z.x, p.y - z.y) > z.r;
        if (!outside) { p.zoneAcc = 0; return; }
        p.zoneAcc += dps * dt;
        if (p.zoneAcc >= 1) {
          const dmg = Math.floor(p.zoneAcc);
          p.zoneAcc -= dmg;
          p.takeTrueDamage(dmg);
          if (!p.alive) this._eliminate(p, null, 'zone');
        }
      });
    }

    // 2) Movimiento y combate
    const list = this._alivePlayers();
    if (list.length >= 2) {
      list.forEach(p => {
        if (!p.alive) return;

        // Enemigo vivo más cercano
        let nearest = null, nd = Infinity;
        list.forEach(o => {
          if (o === p || !o.alive) return;
          const d = (o.x - p.x) ** 2 + (o.y - p.y) ** 2;
          if (d < nd) { nd = d; nearest = o; }
        });
        p.tid = nearest ? nearest.userId : null;
        if (!nearest) return;
        const dist = Math.sqrt(nd);

        // ¿Está en el borde o fuera de la zona? Corre al centro
        const dc = Math.hypot(p.x - z.x, p.y - z.y);
        p.flee = z.phase > 0 && dc > z.r - 14;

        const step = (COMBAT.SPEED[p.tier] || 60) * dt;
        if (p.flee && dc > 1) {
          p.x += ((z.x - p.x) / dc) * step * 1.35;
          p.y += ((z.y - p.y) / dc) * step * 1.35;
        } else if (dist > COMBAT.STOP_DIST) {
          p.x += ((nearest.x - p.x) / dist) * step;
          p.y += ((nearest.y - p.y) / dist) * step;
        }

        // Golpe
        if (dist <= COMBAT.ATTACK_RANGE && this.time >= p.nextAttackAt) {
          p.nextAttackAt = this.time + (COMBAT.COOLDOWN[p.tier] || 1.2) * (0.85 + Math.random() * 0.35);
          const crit = Math.random() < COMBAT.CRIT_CHANCE;
          const base = (COMBAT.DAMAGE[p.tier] || 6) * (0.8 + Math.random() * 0.4) * (crit ? 2 : 1);
          const dmg  = nearest.takeDamage(Math.round(base));
          nearest.effect   = 'attacked';
          nearest.effectAt = Date.now();

          this.emit('combat', {
            attacker:   p.username,
            attackerId: p.userId,
            target:     nearest.username,
            targetId:   nearest.userId,
            damage:     dmg,
            crit,
            reason:     'melee',
          });

          if (!nearest.alive) this._eliminate(nearest, p, 'combat');
        }
      });

      // Separación para que no se apilen
      const MIN_SEP = 20;
      for (let i = 0; i < list.length; i++) {
        for (let j = i + 1; j < list.length; j++) {
          const a = list[i], b = list[j];
          if (!a.alive || !b.alive) continue;
          const dx = b.x - a.x, dy = b.y - a.y;
          const d  = Math.hypot(dx, dy);
          if (d > 0 && d < MIN_SEP) {
            const push = (MIN_SEP - d) / 2;
            a.x -= (dx / d) * push; a.y -= (dy / d) * push;
            b.x += (dx / d) * push; b.y += (dy / d) * push;
          }
        }
      }
    }

    // Mantener dentro del mundo
    list.forEach(p => {
      p.x = clamp(p.x, WORLD.MARGIN, WORLD.W - WORLD.MARGIN);
      p.y = clamp(p.y, WORLD.MARGIN, WORLD.H - WORLD.MARGIN);
    });

    this._checkWinner();
  }

  _eliminate(target, killer, reason) {
    this.alive.delete(target.userId);
    if (killer) killer.kills++;
    this.emit('player_eliminated', {
      player:   target.username,
      playerId: target.userId,
      killedBy: killer ? killer.username : null,
      reason,
    });
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  _alivePlayers() {
    return Array.from(this.players.values()).filter(p => p.alive);
  }

  // Solo se entra durante el lobby y hasta 20 jugadores. El resto va a la cola.
  _getOrCreate(data) {
    if (!this.players.has(data.userId)) {
      if (this.phase !== 'lobby' || this.players.size >= WORLD.MAX_PLAYERS) {
        this._enqueue(data);
        return null;
      }
      const p = new Player(data);
      this.players.set(data.userId, p);
      this.alive.add(data.userId);
      this.emit('player_joined', { player: p.serialize() });
    }
    return this.players.get(data.userId);
  }

  _enqueue(data) {
    const ex = this.queue.get(data.userId);
    if (ex) {
      if (data.profilePictureUrl && !ex.data.profilePictureUrl) ex.data.profilePictureUrl = data.profilePictureUrl;
      return ex;
    }
    if (this.queue.size >= WORLD.MAX_QUEUE) return null;
    const entry = { data: { ...data }, gifts: 0 };
    this.queue.set(data.userId, entry);
    return entry;
  }

  // Pasa a los que esperaban (en orden de llegada) a la nueva ronda
  _fillFromQueue() {
    for (const [userId, entry] of this.queue) {
      if (this.players.size >= WORLD.MAX_PLAYERS) break;
      const p = new Player(entry.data);
      p.gifts = entry.gifts;                 // los regalos que hizo esperando cuentan
      p.tier  = playerTier(p.gifts);
      this.players.set(userId, p);
      this.alive.add(userId);
      this.queue.delete(userId);
      this.emit('player_joined', { player: p.serialize() });
    }
  }

  _checkWinner() {
    if (this.phase !== 'battle') return;
    const aliveList = this._alivePlayers();
    if (aliveList.length > 1) return;

    this.phase   = 'over';
    this.winner  = aliveList[0] ? aliveList[0].serialize() : null;
    if (this.winner) {
      this._sess(this.winner.userId, this.winner.nickname || this.winner.username).wins++;
      this.emit('session', { top: this.sessionTop() });
    }
    this.running = false;
    this._clearTimers();
    this.emit('game_over', { winner: this.winner, queue: this.queue.size });

    // Nueva ronda automática
    clearTimeout(this.resetTimer);
    this.resetTimer = setTimeout(() => this.reset(), this.winner ? 20000 : 10000);
  }

  // ── Bots y demo para modo offline ──────────────────────────────────────────

  _spawnBots() {
    const names = ['Bot_Alpha', 'Bot_Beta', 'Bot_Gamma', 'Bot_Delta', 'Bot_Epsilon', 'Bot_Zeta',
                   'Bot_Eta', 'Bot_Theta', 'Bot_Iota', 'Bot_Kappa', 'Bot_Lambda', 'Bot_Mu',
                   'Bot_Nu', 'Bot_Xi', 'Bot_Omicron', 'Bot_Pi', 'Bot_Rho', 'Bot_Sigma',
                   'Bot_Tau', 'Bot_Upsilon', 'Bot_Phi', 'Bot_Chi', 'Bot_Psi', 'Bot_Omega'];
    const gifts = [0, 0, 0, 5, 0, 20, 0, 150, 0, 0, 2, 0]; // para ver los distintos rangos
    names.forEach((name, i) => {
      this.handleJoin({ userId: `bot_${i}`, username: name, nickname: name });
      const p = this.players.get(`bot_${i}`);
      if (p && gifts[i]) { p.gifts = gifts[i]; p.tier = playerTier(p.gifts); }
    });
  }

  // Simula comentarios y regalos de vez en cuando para probar los efectos
  _demoEvent() {
    const bots = this._alivePlayers().filter(p => String(p.userId).startsWith('bot_'));
    if (bots.length === 0) return;
    const p = randomFrom(bots);
    const base = { userId: p.userId, username: p.username, nickname: p.nickname };
    const r = Math.random();

    if (r < 0.4) {
      this.handleComment({ ...base, comment: 'hola!' });
    } else if (r < 0.6 && bots.length > 1) {
      const other = randomFrom(bots.filter(b => b !== p));
      this.handleComment({ ...base, comment: other.username });
    } else if (r < 0.85) {
      this.handleGift({ ...base, giftId: 1, giftName: 'Rosa', diamondCount: 5, repeatCount: 1 });
    } else if (r < 0.98) {
      this.handleGift({ ...base, giftId: 2, giftName: 'Corazón', diamondCount: 50, repeatCount: 1 });
    } else {
      this.handleGift({ ...base, giftId: 3, giftName: 'León', diamondCount: 300, repeatCount: 1 });
    }
  }

  // ── Handlers de eventos TikTok ────────────────────────────────────────────

  handleJoin(data) {
    if (!this.running) return;
    const p = this._getOrCreate(data);
    if (!p) return; // quedó en cola
    // Actualizar foto si llega después (el evento member a veces trae la URL)
    if (data.profilePictureUrl && !p.profilePictureUrl) {
      p.profilePictureUrl = data.profilePictureUrl;
    }
  }

  handleComment(data) {
    if (!this.running) return;
    const player = this._getOrCreate(data);
    if (!player || !player.alive) return;

    const now = Date.now();
    if (now - player.lastCommentAt < HP.COMMENT_COOLDOWN_MS) return;

    player.lastCommentAt = now;

    // Detectar si el comentario es un ataque a otro jugador (escribe su username)
    const comment = data.comment.toLowerCase().trim();
    // Ataques por comentario solo durante la batalla (en el lobby todos curan)
    const target = this.phase !== 'battle' ? null : this._alivePlayers().find(
      p => p.userId !== player.userId &&
           now - p.lastHitAt >= HP.HIT_COOLDOWN_MS &&
           (comment.includes(p.username.toLowerCase()) || comment.includes(p.nickname.toLowerCase()))
    );

    if (target) {
      target.lastHitAt = now;
      const dmg = target.takeDamage(15);
      target.effect = 'attacked';
      target.effectAt = Date.now();
      this.emit('comment_attack', {
        attacker: player.username,
        target:   target.username,
        damage:   dmg,
      });
      if (!target.alive) {
        this.alive.delete(target.userId);
        player.kills++;
        this.emit('player_eliminated', {
          player:   target.username,
          killedBy: player.username,
          reason:   'comment',
        });
        this._checkWinner();
      }
    } else {
      // Comentario normal → +HP
      player.heal(HP.COMMENT_GAIN);
      this.emit('comment_heal', {
        player: player.username,
        amount: HP.COMMENT_GAIN,
      });
    }
  }

  handleGift(data) {
    if (!this.running) return;
    const dd = (data.diamondCount || 0) * (data.repeatCount || 1);
    if (dd > 0) {
      this._sess(data.userId, data.nickname || data.username).diamonds += dd;
      this.emit('session', { top: this.sessionTop() });
    }
    const sender = this._getOrCreate(data);
    if (!sender) {
      // Está en cola: su regalo no se pierde, sube su rango para la próxima ronda
      const q = this.queue.get(data.userId);
      if (q) q.gifts += (data.diamondCount || 0) * (data.repeatCount || 1);
      return;
    }
    if (data.profilePictureUrl && !sender.profilePictureUrl) {
      sender.profilePictureUrl = data.profilePictureUrl;
    }

    const totalDiamonds = data.diamondCount * (data.repeatCount || 1);
    sender.gifts += totalDiamonds;
    sender.tier = playerTier(sender.gifts);

    const tier = giftTier(data.diamondCount);

    // En el lobby no hay daño: cualquier regalo cura y sube la vida máxima
    if (this.phase === 'lobby' && tier.action !== 'heal') {
      sender.heal(tier.value);
      sender.upgradeMaxHp(20);
      this.emit('gift_heal', { player: sender.username, giftName: data.giftName, amount: tier.value, diamonds: totalDiamonds });
      return;
    }

    switch (tier.action) {

      case 'heal': {
        // Gift pequeño → se cura a sí mismo + sube maxHP
        sender.heal(tier.value);
        sender.upgradeMaxHp(20);
        this.emit('gift_heal', {
          player:    sender.username,
          giftName:  data.giftName,
          amount:    tier.value,
          diamonds:  totalDiamonds,
        });
        break;
      }

      case 'attack': {
        // Gift mediano → ataca al jugador con más HP (amenaza principal)
        const targets = this._alivePlayers().filter(p => p.userId !== sender.userId);
        if (targets.length === 0) break;
        const target = targets.reduce((a, b) => a.hp > b.hp ? a : b);
        const dmg = target.takeDamage(tier.value);
        target.effect = 'attacked';
        target.effectAt = Date.now();
        sender.addArmor(5); // bonus de armadura al atacante
        this.emit('gift_attack', {
          attacker:  sender.username,
          target:    target.username,
          giftName:  data.giftName,
          damage:    dmg,
          diamonds:  totalDiamonds,
        });
        if (!target.alive) {
          this.alive.delete(target.userId);
          sender.kills++;
          this.emit('player_eliminated', {
            player:   target.username,
            killedBy: sender.username,
            reason:   'gift',
          });
          this._checkWinner();
        }
        break;
      }

      case 'bomb': {
        // Gift grande → bomba de área, daño a todos excepto sender
        // Pero si alguien tiene suficiente HP/armadura sobrevive
        const aliveList = this._alivePlayers().filter(p => p.userId !== sender.userId);
        const eliminated = [];
        aliveList.forEach(p => {
          const dmg = p.takeDamage(tier.value);
          p.effect = 'bombed';
          p.effectAt = Date.now();
          if (!p.alive) {
            this.alive.delete(p.userId);
            sender.kills++;
            eliminated.push(p.username);
          }
        });
        sender.addArmor(10);
        sender.heal(50);
        this.emit('gift_bomb', {
          sender:      sender.username,
          giftName:    data.giftName,
          damage:      tier.value,
          eliminated:  eliminated,
          diamonds:    totalDiamonds,
        });
        eliminated.forEach(name => {
          this.emit('player_eliminated', {
            player:   name,
            killedBy: sender.username,
            reason:   'bomb',
          });
        });
        this._checkWinner();
        break;
      }

      case 'mega_bomb': {
        // Gift mega → bomba masiva, daño enorme, sender gana escudo completo
        const aliveList = this._alivePlayers().filter(p => p.userId !== sender.userId);
        const eliminated = [];
        aliveList.forEach(p => {
          const dmg = p.takeDamage(tier.value);
          p.effect = 'bombed';
          p.effectAt = Date.now();
          if (!p.alive) {
            this.alive.delete(p.userId);
            sender.kills++;
            eliminated.push(p.username);
          }
        });
        sender.addArmor(25);
        sender.heal(150);
        sender.upgradeMaxHp(100);
        this.emit('gift_mega_bomb', {
          sender:     sender.username,
          giftName:   data.giftName,
          damage:     tier.value,
          eliminated: eliminated,
          diamonds:   totalDiamonds,
        });
        eliminated.forEach(name => {
          this.emit('player_eliminated', {
            player:   name,
            killedBy: sender.username,
            reason:   'mega_bomb',
          });
        });
        this._checkWinner();
        break;
      }
    }
  }

  // Los likes son personales: solo curan a quien los da (cada LIKE_BATCH likes = +HP.LIKE_HEAL)
  handleLike(data) {
    if (!this.running) return;
    const player = this.players.get(data.userId);
    if (!player || !player.alive) return;

    player.likeAcc += data.likeCount || 1;
    let batches = 0;
    while (player.likeAcc >= HP.LIKE_BATCH) {
      player.likeAcc -= HP.LIKE_BATCH;
      batches++;
    }
    if (!batches) return;

    const heal = batches * HP.LIKE_HEAL;
    player.heal(heal);
    this.emit('like_event', {
      player:  player.username,
      trigger: batches * HP.LIKE_BATCH,
      heal,
    });
  }

  handleShare(data) {
    if (!this.running) return;
    const player = this.players.get(data.userId);
    if (!player || !player.alive) return;

    player.heal(HP.SHARE_BONUS);
    player.addArmor(5);
    this.emit('share_bonus', {
      player: player.username,
      heal:   HP.SHARE_BONUS,
      armor:  5,
    });
  }
}

module.exports = { GameEngine, WORLD };
